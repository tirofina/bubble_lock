const axios = require("axios");
const config = require("config");
const { Op } = require('sequelize');

const logger = require("../logger").forFile(__filename);
const mqtt = require("../bindings/mqtt");
const SUB = require('../models/sub-model');
const AE = require('../models/ae-model');
const Lookup = require('../models/lookup-model');
const { not_obsolete_where } = require('./utils');
const { comparison_conditions_match, resource_of } = require('./enc-conditions');
const { NCT, effective_nct, notification_carries_subscribed_to } = require('./notification-event-types');

// BUBBLE_SUBSCRIPTION_SECURITY_V2: a notification may leave the CSE only for an explicitly approved origin.
const notification_ports = { 'http:': '80', 'https:': '443', 'mqtt:': '1883', 'mqtts:': '8883' };
function notification_origin(value) {
    try {
        const url = new URL(value);
        const port = url.port || notification_ports[url.protocol];
        return port && !url.username && !url.password
            ? url.protocol + '//' + url.hostname + ':' + port : null;
    } catch { return null; }
}
const configured_notification_origins = config.has('cse.notification_allowed_origins')
    ? config.get('cse.notification_allowed_origins') : [];
if (!Array.isArray(configured_notification_origins) || configured_notification_origins.some((value) => {
    if (typeof value !== 'string' || !notification_origin(value)) return true;
    const url = new URL(value);
    return !['', '/'].includes(url.pathname) || Boolean(url.search || url.hash);
})) throw new Error('cse.notification_allowed_origins must contain only URL origins');
const allowed_notification_origins = new Set(configured_notification_origins.map(notification_origin));
function notification_target_allowed(target) {
    const origin = notification_origin(target);
    return origin !== null && allowed_notification_origins.has(origin);
}


// supported notificationEventType (net) = {
//     1: Update of Resource
//     2: Delete of Resource
//     3: Create of Direct Child Resource
//     4: Delete of Direct Child Resource
// }

// The attribute names an UPDATE request actually carries. req_prim.pc holds the update
// representation inside its envelope ({"m2m:cnt": {lbl: [...]}}), so the inner keys are exactly
// the attributes the Originator asked to change. This is the same source nct=2 ("modified
// attributes") already sends as notification content, which is why no separate diff is needed.
function updated_attribute_names(req_prim) {
    const pc = req_prim.pc;
    if (!pc || typeof pc !== 'object') return [];
    const envelope_key = Object.keys(pc)[0];
    const body = envelope_key === undefined ? null : pc[envelope_key];
    if (!body || typeof body !== 'object') return [];
    return Object.keys(body);
}

// The "attribute" condition of eventNotificationCriteria (TS-0001:9.6.8 table 9.6.8-3): when the
// list is present it names the subset of the subscribed-to resource's attributes whose update
// generates a notification -- "If an attribute that is not specified in this list is updated, then
// a notification shall not be generated". When absent, the default is the full attribute set.
//
// The clause scopes the list to notificationEventType "Update to attributes of the subscribed-to
// resource" (net=1) and to its blocking variant (net=7, which mobius4 does not implement), so the
// net=2/3/4 branches are deliberately left alone.
//
// Names are compared as they arrive on the wire (short names). No long/short translation is done:
// the update representation and the condition list are both written by the same Originator in the
// same naming, and translating one side only would make them stop matching.
function attribute_condition_matches(enc, req_prim) {
    // An empty list cannot arrive through the API -- the create/update schema requires min(1),
    // because m2m:attributeList carries xs:minLength 1. Treating a hand-edited empty row as "no
    // condition" keeps it from silencing a subscription outright.
    if (!Array.isArray(enc.atr) || enc.atr.length === 0) return true;
    return updated_attribute_names(req_prim).some(name => enc.atr.includes(name));
}

// The attributes that actually changed, as a partial resource.
//
// TS-0004:7.5.1.2.2 step 2.1: with notificationContentType "Modified Attributes" the notification
// "shall include the partial resource containing modified attribute(s) only". Modified, not
// requested -- and the two are different on every UPDATE this CSE performs. Updating an <AE>'s
// labels also moves its lastModifiedTime; updating a <container> moves stateTag as well; and an
// attribute the request never mentioned can change because something else did it. Sending back
// only what the Originator asked to change reported a resource state that never existed.
//
// So it is a comparison of the representation before the operation with the one after, which also
// covers the indirect cases without having to enumerate them.
//
// An attribute that is gone afterwards is reported as null, the same way an UPDATE asks for its
// removal. The clause does not say how a partial resource spells a deletion, and omitting it would
// make "removed" indistinguishable from "unchanged".
function modified_attributes(before_pc, after_pc) {
    const after = resource_of(after_pc);
    if (!after) return after_pc;
    const before = resource_of(before_pc) || {};
    const key = Object.keys(after_pc)[0];

    const changed = {};
    for (const [name, value] of Object.entries(after)) {
        if (JSON.stringify(before[name]) !== JSON.stringify(value)) changed[name] = value;
    }
    for (const name of Object.keys(before)) {
        if (!Object.hasOwn(after, name)) changed[name] = null;
    }
    return { [key]: changed };
}

// The structured ID of the subscribed-to resource. A <subscription>'s own sid is that resource's
// sid with the subscription's resourceName appended, so it is already here and needs no query.
function subscribed_to_sid(sub_res) {
    const sid = sub_res.sid || '';
    const cut = sid.lastIndexOf('/');
    return cut === -1 ? sid : sid.slice(0, cut);
}

// The notification content for one subscription, per its notificationContentType.
//
// `subject_sid` is the structured ID of the resource the notification is about: the subscribed-to
// resource for net=1 and net=2, the child for net=3 and net=4.
function notification_content(nct, { full_pc, before_pc, requested_pc, subject_sid }) {
    switch (nct) {
        case NCT.MODIFIED:
            // before_pc is absent when no subscriber needed it at the time the operation ran --
            // the snapshot is only taken when one does. Falling back to what was requested is what
            // this used to do always, and is closer than sending everything.
            return before_pc ? modified_attributes(before_pc, full_pc) : (requested_pc || full_pc);
        case NCT.RESOURCE_ID:
            // "the Notify request primitive shall include the URI of the resource"
            // (TS-0004:7.5.1.2.2 step 2.1).
            return { 'm2m:uri': subject_sid };
        default:
            return full_pc;
    }
}

// Does anything subscribed to this resource need to know which attributes changed?
//
// Asked before an UPDATE runs, because "modified attributes" can only be worked out by comparing
// the representation before with the one after, and afterwards the before is gone. The answer is
// almost always no, and the cost of asking is one indexed count on a table the notification path
// reads anyway -- which is the point of asking rather than snapshotting unconditionally.
async function wants_modified_attributes(res_ri) {
    if (!res_ri) return false;
    const n = await SUB.count({ where: { pi: res_ri, nct: 2, ...not_obsolete_where() } });
    return n > 0;
}

async function check_and_send_noti(req_prim, resp_prim, event_type, before_pc = null, deleted_snapshot = null) {
    const sub_res_pi = req_prim.ri;

    // Fire this SELECT off first (it is awaited further down). hostingCSE.delete_a_res runs the
    // notification path and the cascade delete at the same time, so if the query for this
    // resource's own subscriptions were pushed behind the net=4 lookup and went out late,
    // SUB.destroy in delete_resources would get there first and this resource's net=2
    // notification would silently vanish. Issuing the SELECT in the same tick, before the net=4
    // await, eliminates that race.
    // Obsolete subscriptions are excluded here, not left to the sweep. TS-0004:7.5.1.2.2 does not
    // name expirationTime among its steps, but a notification is the one externally visible proof
    // that a subscription is still live, and TS-0001:9.6.1.3.2 calls the resource 'obsolete' from
    // the moment its et passes. The same clause pairing is already made for aggregation in
    // TS-0004:7.5.1.2.6 — "the group-hosting CSE shall perform notification aggregation **while
    // the <group> resource has not expired**". Reported by a client whose crash-recovery design
    // leaned on et as a lease: notifications kept being published for a whole sweep interval to
    // targets that had gone away (DEC-094).
    const sub_res_p = SUB.findAll({ where: { pi: sub_res_pi, ...not_obsolete_where() } });

    // net=4 has to look at the subscriptions under the **parent** of the deleted resource, so it
    // is handled **before** the self-based query below and its "return early if there are zero
    // subscriptions" shortcut. That keeps net=4 from being missed entirely when a resource with
    // no subscriptions beneath itself — a CIN, for example — is deleted and the early return hits.
    //
    // int_cr_req marks internal requests such as eviction. Whether indirect deletion is supposed
    // to raise a notification is still awaiting a spec check (SQ-001, DEC-039), so for now it
    // does not fire.
    //
    // The .catch isolates failures: if a net=4 subscription on the parent throws (a bad nu, say),
    // that exception would propagate out of this function and block the whole net=1/2/3 path
    // below — losing the deleted resource's *own* notification because of a fault on the parent
    // side is collateral damage beyond what this function is responsible for.
    if (event_type === 'delete' && req_prim.int_cr_req !== true) {
        await notify_parent_of_child_deletion(resp_prim.pc, req_prim.to_ty)
            .catch((err) => logger.warn({ err }, 'net=4 parent notification failed'));
    }

    const sub_res = (await sub_res_p).map(sub => sub.toJSON());

    if (sub_res.length === 0) return;

    // pre-fetch all AE poa values in one batch to avoid N+1 queries
    const ae_poa_map = await prefetch_ae_poa(sub_res);

    // The resource the comparison conditions are measured against. TS-0001:9.6.8 table 9.6.8-3
    // scopes the other conditions to the selected notificationEventType -- for net=3 that is the
    // created child, which is what resp_prim.pc holds on the create path, and for net=1/2 the
    // subscribed-to resource, which is what it holds on the update and delete paths. In every case
    // it is the same object the notification carries as nev.rep.
    //
    // Deliberately not req_prim.pc, even for an nct=2 subscription. req_prim.pc is the UPDATE
    // request body, and ct/lt/st/cs are server-assigned -- they can never appear in it. Evaluating
    // the comparison conditions against it would silently make every one of them false, so nct
    // governs only what is sent, not what is judged.
    const event_res = resource_of(resp_prim.pc);

    await Promise.all(sub_res.map(async (sub) => {
        if (!sub.enc) sub.enc = { net: [1] };

        if (!comparison_conditions_match(sub.enc, event_res)) return;

        const nct = effective_nct(sub.enc, sub.nct);
        const own_sid = subscribed_to_sid(sub);
        // For a child event the notification is about the child, so its structured ID is the
        // subscribed-to resource's plus the child's resourceName.
        const child_rn = event_res && event_res.rn;
        const child_sid = child_rn ? `${own_sid}/${child_rn}` : own_sid;

        if (sub.enc.net.includes(3) && event_type === 'create') {
            const this_ty = req_prim.ty;
            if (!sub.enc.chty || sub.enc.chty.includes(this_ty)) {
                await send_a_noti(sub, notification_content(nct, {
                    full_pc: resp_prim.pc, subject_sid: child_sid,
                }), 3, ae_poa_map);
            }
        } else if (sub.enc.net.includes(1) && event_type === 'update') {
            if (attribute_condition_matches(sub.enc, req_prim)) {
                await send_a_noti(sub, notification_content(nct, {
                    full_pc: resp_prim.pc, before_pc, requested_pc: req_prim.pc,
                    subject_sid: own_sid,
                }), 1, ae_poa_map);
            }
        } else if (sub.enc.net.includes(2) && event_type === 'delete') {
            await send_a_noti(sub, notification_content(nct, {
                full_pc: resp_prim.pc, subject_sid: own_sid,
            }), 2, ae_poa_map, deleted_snapshot);
        }
    }));

    return true;
}

// net=4 (Delete of Direct Child Resource): the subscription sits under the **parent** of the
// deleted child, not under the child itself. The default query in check_and_send_noti
// (pi === req_prim.ri) only finds subscriptions that are children of the deleted resource, so it
// would never find a net=4 one. Hence this separate parent-based query.
//
// Why this is split out to take only the deleted resource's representation and type (DEC-039):
// eviction and cascade descendant deletion are out of scope until the spec check (SQ-001) is
// settled, but once it is, the feature can be extended by adding call sites alone.
async function notify_parent_of_child_deletion(deleted_pc, deleted_ty) {
    const deleted_res = deleted_pc && Object.values(deleted_pc)[0];
    const parent_ri = deleted_res && deleted_res.pi;
    if (!parent_ri) return false;

    // Same expiry gate as check_and_send_noti — net=4 reads a different row set (the parent's
    // subscriptions), so it needs the predicate of its own.
    const parent_subs = (await SUB.findAll({ where: { pi: parent_ri, ...not_obsolete_where() } }))
        .map(sub => sub.toJSON());
    if (parent_subs.length === 0) return false;

    const targets = parent_subs.filter((sub) => {
        // With no enc the default is Update_of_Resource, so it is not a net=4 target
        // (TS-0004:7.5.1.2.2 Step 1.0).
        if (!sub.enc || !Array.isArray(sub.enc.net) || !sub.enc.net.includes(4)) return false;
        // When chty is present, fire only if the deleted child's type is in the list. When it
        // is absent, fire for every child type (same clause Step 1.0 — the rule net=3 follows).
        if (!comparison_conditions_match(sub.enc, resource_of(deleted_pc))) return false;
        return !sub.enc.chty || sub.enc.chty.includes(deleted_ty);
    });
    if (targets.length === 0) return false;

    const ae_poa_map = await prefetch_ae_poa(targets);
    await Promise.all(targets.map((sub) => {
        const nct = effective_nct(sub.enc, sub.nct);
        const own_sid = subscribed_to_sid(sub);
        const subject_sid = deleted_res && deleted_res.rn ? `${own_sid}/${deleted_res.rn}` : own_sid;
        return send_a_noti(sub, notification_content(nct, { full_pc: deleted_pc, subject_sid }), 4, ae_poa_map);
    }));
    return true;
}

// batch-load AE poa for all non-URL nu targets across all subscriptions
async function prefetch_ae_poa(sub_list) {
    const { get_to_info } = require('./reqPrim');

    // collect unique AE resource IDs (nu that are not http/mqtt URLs)
    const res_id_set = new Set();
    for (const sub of sub_list) {
        for (const nu of (sub.nu || [])) {
            if (!nu.startsWith('http') && !nu.startsWith('mqtt')) {
                const { shortest_to } = get_to_info({ to: nu });
                if (shortest_to) res_id_set.add(shortest_to);
            }
        }
    }

    if (res_id_set.size === 0) return {};

    const res_ids = [...res_id_set];

    // batch-resolve structured IDs to ri
    const structured = res_ids.filter(id => id.includes('/'));
    const unstructured = res_ids.filter(id => !id.includes('/'));

    const lookups = structured.length > 0
        ? await Lookup.findAll({ where: { sid: structured }, attributes: ['ri', 'sid'] })
        : [];

    const sid_to_ri = Object.fromEntries(lookups.map(l => [l.sid, l.ri]));
    const all_ri = [
        ...lookups.map(l => l.ri),
        ...unstructured,
    ];

    if (all_ri.length === 0) return {};

    // batch-fetch AE poa in a single query
    const ae_list = await AE.findAll({
        where: { ri: { [Op.in]: all_ri } },
        attributes: ['ri', 'poa'],
    });
    const ri_to_poa = Object.fromEntries(ae_list.map(ae => [ae.ri, ae.poa]));

    // build map: res_id → poa[]
    const poa_map = {};
    for (const res_id of res_ids) {
        const ri = sid_to_ri[res_id] || res_id;
        poa_map[res_id] = ri_to_poa[ri] || [];
    }
    return poa_map;
}

// BUBBLE_SUBSCRIPTION_SECURITY_V2: re-evaluate subscription data and notification-target privileges at delivery.
async function send_a_noti(sub_res, event_obj, notificationEventType, ae_poa_map = {}, deleted_snapshot = null) {
    if (sub_res == null) return;
    const creator = sub_res.int_cr || sub_res.cr;
    if (!creator) return;
    const { access_decision } = require('./hostingCSE');
    const parent = await Lookup.findByPk(sub_res.pi);
    const snapshot_resource = deleted_snapshot && Object.values(deleted_snapshot)[0];
    const snapshot = !parent && notificationEventType === 2 && snapshot_resource?.ri === sub_res.pi ? deleted_snapshot : null;
    if (!parent && !snapshot) return;
    const readable = await access_decision({ ri: sub_res.pi, to_ty: parent?.ty || snapshot_resource?.ty, op: 2, fr: creator }, {}, snapshot);
    if (!readable) return;

    const sgn = {
        "m2m:sgn": {
            nev: { rep: event_obj, net: notificationEventType },
            sur: sub_res.sid,
        },
    };

    // TS-0004:7.5.1.2.2 step 2.1: subscribedTo carries the subscribed-to resource's ID "if
    // notificationContentType is set to one of Modified Attributes, Trigger Payload or TimeSeries
    // notification. Otherwise, the subscribedTo attribute shall not be present." Both halves are
    // requirements, which is why this is a condition rather than always setting it: with a partial
    // resource or a timeSeriesNotification the payload does not say which resource it is about,
    // and with a full representation it does.
    if (notification_carries_subscribed_to(effective_nct(sub_res.enc, sub_res.nct))) {
        sgn["m2m:sgn"].sut = subscribed_to_sid(sub_res);
    }

    // TS-0004:7.5.1.2.2 step 2.1 (repeated in 7.5.1.2.3/.4/.19/.20): "if the <subscription>
    // resource instance has the creator attribute, the Originator shall set the creator element
    // of the notification data object to the value of the <subscription> resource's creator
    // attribute."
    //
    // Without it a consumer cannot tell, from the notification alone, whose subscription produced
    // it — which is what a gateway needs in order to drop the echo of its own writes. Note this
    // is the *subscription's* creator; the changed resource's own cr travels inside nev.rep and
    // is a different attribute.
    if (sub_res.cr) sgn["m2m:sgn"].cr = sub_res.cr;

    for (const noti_target of sub_res.nu) {
        if (noti_target.startsWith('http'))  { http_noti(noti_target, sgn); continue; }
        if (noti_target.startsWith('mqtt'))  { mqtt_noti(noti_target, sgn); continue; }

        // AE resource ID — use pre-fetched poa map, fall back to DB query if not found
        //
        // Every way this can fail used to fail silently. A notificationURI naming an <AE> with no
        // pointOfAccess produced no log line at all: the loop below simply had nothing to iterate,
        // and the send paths that do log warnings were never reached. From outside, and from the
        // log, that is indistinguishable from a notification that was never generated -- which is
        // the harder thing to debug, because it sends you looking at the subscription's conditions
        // instead of at the target.
        const { get_to_info } = require('./reqPrim');
        const { shortest_to: res_id } = get_to_info({ to: noti_target });
        if (!res_id) {
            logger.warn({ target: noti_target, sur: sgn['m2m:sgn']?.sur },
                'notification target is not a resolvable resource ID; notification dropped');
            continue;
        }

        const target = await Lookup.findOne({ where: { [Op.or]: [{ ri: res_id }, { sid: res_id }] } });
        if (!target) continue;
        const target_request = { ri: target.ri, to_ty: target.ty, op: 5 };
        const creator_notify = await access_decision({ ...target_request, fr: creator }, {});
        const host_notify = await access_decision({ ...target_request, fr: config.cse.cse_id }, {});
        if (!creator_notify || !host_notify) continue;
        const urls = ae_poa_map[res_id] ?? await get_urls_from_poa(res_id);
        if (urls.length === 0) {
            logger.warn({ target: noti_target, res_id, sur: sgn['m2m:sgn']?.sur },
                'notification target has no pointOfAccess to deliver to; notification dropped');
            continue;
        }

        // TS-0004:7.5.1.2.2: "The Originator shall fetch the notificationURI attribute and set the
        // value to the To parameter of the Notify request." To is multiplicity 1 on every request
        // primitive (TS-0004 table 6.4.1-1), and a Notify is one.
        //
        // A pointOfAccess is where to send it, not what to address. Posting to the bare poa left
        // the request-URI as "/" -- and TS-0009:6.2.2.1 carries To *as* the request-URI path
        // component, so the receiver saw a Notify with an empty To. A notificationURI written as a
        // URL never had this problem: the URL is both the destination and the To.
        //
        // MQTT does not put To in the path -- the topic is the destination -- so there the value
        // travels in the primitive itself.
        let delivered = false;
        for (const url of urls) {
            let result = null;
            if (url.startsWith('http')) {
                const { to_path_component } = require('./reqPrim');
                result = await http_noti(url.replace(/\/+$/, '') + to_path_component(noti_target), sgn);
            } else if (url.startsWith('mqtt')) {
                result = await mqtt_noti(url, sgn, noti_target);
            }
            if (result === true) { delivered = true; break; }
        }
        if (!delivered) {
            logger.warn({ target: noti_target, res_id, poa: urls, sur: sgn['m2m:sgn']?.sur },
                'notification was not delivered on any pointOfAccess');
        }
    }
}

async function send_sub_del_noti(sub_res) {
    // this works only when the sub resource has a 'su' attribute
    const subscriberURI = sub_res.su;
    if (!subscriberURI) 
        return;

    const { get_structuredID } = require('./hostingCSE');
    
    const sgn = {
        "m2m:sgn": {
            sud: true,
            sur: await get_structuredID(sub_res.ri),
        }
    };

    
    if (subscriberURI.indexOf("http") == 0) http_noti(subscriberURI, sgn);
    else if (subscriberURI.indexOf("mqtt") == 0) mqtt_noti(subscriberURI, sgn);
    else {
        // last case: subscriberURI represents the ID of an <AE> resource, not a HTTP/MQTT URL
        const { get_to_info } = require('./reqPrim');
        const { shortest_to: res_id } = get_to_info({ to: subscriberURI });

        if (res_id) {
            const urls = await get_urls_from_poa(res_id);

            for (const url of urls) {
                let result = null;
                if (url.indexOf("http") == 0) result = await http_noti(url, sgn);
                else if (url.indexOf("mqtt") == 0) result = await mqtt_noti(url, sgn);

                // if the notification is sent successfully, stop the loop
                if (result === true) break;
            }
        }
    }
    
}

async function http_noti(noti_target, sgn) {
    if (!notification_target_allowed(noti_target)) {
        logger.warn({ target: noti_target, sur: sgn['m2m:sgn']?.sur }, 'notification target origin denied');
        return false;
    }
    const { generate_ri } = require('./utils');
    const rqi = 'http-noti-' + generate_ri();

    // The record of what actually went out, in the same shape cse/reqPrim.js logs a forwarded
    // request in. Only the target and sur were logged before, so a notification could not be read
    // back from the log at all -- what a receiver was sent had to be inferred from the resource
    // that triggered it. At debug rather than info because notifications are as frequent as the
    // events that cause them, where a forwarded request is not.
    //
    // rqi is generated here rather than inline in the headers so this line and the X-M2M-RI the
    // receiver sees are the same value. A log entry naming a different identifier than the wire
    // cannot be matched against the other side's log, which is most of what it is for.
    logger.debug({
        prim: { to: noti_target, fr: config.cse.cse_id, rqi, rvi: config.cse.versions[0],
                op: 5, pc: sgn },
        method: 'post', url: noti_target,
    }, 'notification primitive sent');

    // axios handles HTTP and HTTPs automatically
    axios
        .request({
            url: noti_target,
            method: "post",
            headers: {
                "X-M2M-Origin": config.cse.cse_id,
                "X-M2M-RI": rqi,
                // A notification is a request primitive, and TS-0004:6.4.1 gives Release Version
                // Indicator multiplicity 1 -- it is mandatory on every one. This header was
                // missing, and a receiver that checks its request parameters rejected the
                // notification because of it. The value is the first entry of cse.versions, the
                // same source the MQTT notification path and the retargeting path already use, so
                // all three agree on what release this CSE speaks.
                "X-M2M-RVI": config.cse.versions[0],
                "Content-Type": "application/json",
            },
            data: sgn,
            timeout: config.cse.notification_timeout_seconds * 1000,
            maxRedirects: 0,
        })
        .then((resp) => {
            logger.debug({ target: noti_target, status: resp.status }, 'http notification acknowledged');
        })
        .catch((err) => {
            const sur = sgn['m2m:sgn'].sur;
            if (err.response) {
                logger.warn({ sur, target: noti_target, status: err.response.status, data: err.response.data }, 'http notification rejected by target');
            } else {
                logger.warn({ sur, target: noti_target, code: err.code, err }, 'http notification delivery failed');
            }
        });

    return true;
}

// to_override is the notificationURI when it named a resource rather than this broker URL --
// see the comment in send_a_noti. Without it To would be the mqtt:// URL, which is the destination
// and not what the notification is addressed to.
async function mqtt_noti(noti_target, sgn, to_override) {
    if (!notification_target_allowed(noti_target)) {
        logger.warn({ target: noti_target, sur: sgn['m2m:sgn']?.sur }, 'notification target origin denied');
        return false;
    }
    // oneM2M defined MQTT URL convention: mqtt://<IP>:<PORT>/<topic>
    const url_without_protocol = noti_target.split("//")[1];
    const topic_index = url_without_protocol.indexOf("/");

    // when nu is URL, use nu as the MQTT topic
    let topic = url_without_protocol.substring(topic_index + 1);

    // remove trailing option for serialization (e.g. '?ct=json)
    if (topic.includes("?")) {
        topic = topic.split("?")[0] + '/json';
    } else {
        topic = topic + '/json';
    }

    const { generate_ri } = require('./utils');
    const req_prim = {
        to: to_override || noti_target,
        fr: config.cse.cse_id,
        ri: 'mqtt-noti-' + generate_ri(),
        op: 5, // 5: notify
        pc: sgn,
    };

    logger.debug({
        prim: { to: req_prim.to, fr: req_prim.fr, rqi: req_prim.ri, rvi: config.cse.versions[0],
                op: 5, pc: sgn },
        topic,
    }, 'notification primitive sent');

    // Published to the broker the URL names, not to this CSE's own. TS-0010:6.6.2 makes the
    // authority part of the URL meaningful; sending everything to the local broker delivered the
    // right topic to the wrong server, which looks identical in the logs and delivers nothing.
    // bindings/mqtt-outbound.js short-circuits back to the local client when the URL does name it.
    const mqtt_outbound = require('../bindings/mqtt-outbound');
    const result = await mqtt_outbound.publish_to_url(noti_target, req_prim, { topic_override: topic });
    if (result === false) {
        logger.warn({ target: noti_target, topic }, 'mqtt notification delivery failed');
        return false;
    }
    return true;
}

// TS-0004:7.5.1.2.3 sender side: the Hosting CSE sends a Subscription Verification request
// primitive to a resource-ID notificationURI entry before the <subscription> that names it is
// created. Unlike http_noti (fire-and-forget, returns a boolean once the request is dispatched),
// the caller here (cse/subscription-verification.js's verify_targets) has to decide whether the
// creation can proceed, so this awaits the response and hands back the actual X-M2M-RSC.
//
// Two distinct failure shapes both matter to the caller and are kept apart on purpose:
//   - no reachable poa, or the request never got a response at all (network error, timeout) --
//     "the request cannot be sent" (Recv-6.4) -- this throws.
//   - the request was sent and answered, whatever the RSC -- this returns that RSC, even when it
//     is one the HTTP binding maps to a non-2xx status (bindings/http.js maps 4103 to 403, for
//     example). validateStatus below is what keeps axios from turning that into a thrown error
//     indistinguishable from "could not be sent".
async function send_verification(target, creator, sub_sid, timeout_ms) {
  const { get_to_info } = require('./reqPrim');
  const { generate_ri } = require('./utils');

  const { shortest_to: res_id } = get_to_info({ to: target });
  const urls = res_id ? await get_urls_from_poa(res_id) : [];
  const poa = urls.find((u) => u.startsWith('http'));
  if (!poa) throw new Error(`no reachable pointOfAccess for ${target}`);

  // TS-0004:7.5.1.2.3 step 1: "Set the To parameter as the notificationURI in the primitive."
  // Carried as the request-URI path component (TS-0009:6.2.2.1) -- posting to the bare
  // pointOfAccess sent a verification request with an empty To.
  const { to_path_component } = require('./reqPrim');
  const url = poa.replace(/\/+$/, '') + to_path_component(target);
  if (!notification_target_allowed(url)) throw new Error('notification target origin denied');

  const rqi = 'verif-noti-' + generate_ri();
  logger.debug({
      prim: { to: target, fr: config.cse.cse_id, rqi, rvi: config.cse.versions[0], op: 5,
              pc: { "m2m:sgn": { vrq: true, cr: creator, sur: sub_sid } } },
      method: 'post', url,
  }, 'notification primitive sent');

  const resp = await axios.request({
    url,
    method: "post",
    headers: {
      "X-M2M-Origin": config.cse.cse_id,
      "X-M2M-RI": rqi,
      "X-M2M-RVI": config.cse.versions[0],
      "Content-Type": "application/json",
    },
    // subscriptionReference is multiplicity 1 in TS-0004 table 6.3.5.13-1, and
    // CDT-notification.xsd declares it with no minOccurs, so it is mandatory on every
    // notification -- a verification request included. It was left out at first because
    // TS-0004:7.5.1.2.3 lists only verificationRequest, creator and To; the procedure clause
    // enumerates what that procedure sets, it does not relieve the primitive of its own required
    // members, and a receiver validating the data type rejected the notification for its absence.
    //
    // The value is the structured ID the <subscription> is about to be given. Verification runs
    // before the insert, so the resource does not exist yet -- but its name is already fixed
    // (create_a_sub derives sub_sid from the parent and rn before any of this), and it is the
    // same value an ordinary notification from that subscription will carry.
    data: { "m2m:sgn": { vrq: true, cr: creator, sur: sub_sid } },
    timeout: timeout_ms,
    maxRedirects: 0,
    validateStatus: () => true,
  });
  return resp.headers['x-m2m-rsc'];
}

async function get_urls_from_poa(res_id) {
    const { get_unstructuredID } = require('./hostingCSE');
    const ri = await get_unstructuredID(res_id);
    const ae_res = await AE.findByPk(ri);
    if (!ae_res) {
        return [];
    }
    return ae_res.poa;
}

function self_noti_handler(topic, req_prim) {
    logger.debug({ topic }, 'self notification received');

    // Reached only from bindings/mqtt.js for internal `self/...` topics, so a verification
    // request cannot arrive here today. Guarded anyway: the read below assumes both nev and sur,
    // and CDT-notification.xsd allows a notification with neither.
    const sgn = req_prim.pc && req_prim.pc['m2m:sgn'];
    if (!sgn || !sgn.nev || !sgn.sur) {
        logger.debug({ topic }, 'self notification without nev/sur ignored');
        return;
    }

    const res = sgn.nev.rep;
    const sub_rn = sgn.sur.split('/').pop();
    const dsp_ri = sub_rn.split('sub-live-dataset-')[1];

    // self notification to create live dataset
    if (topic.startsWith('self/datasetManager/')) {
        if (res['m2m:cin']) {
            const time = res['m2m:cin'].ct;
            const data = res['m2m:cin'].con;

            const flat_data = get_flat_data(time, data);
            batch_noti_data(dsp_ri, flat_data);
        }
    }
    
    return;
}

function get_flat_data(time, data) {
    const { get_feature_list } = require('./datasetManager');
    const JSONPath = require('jsonpath-plus');

    const features = get_feature_list(data);
    const flat_data = {};

    for (const feature of features) {
        try {
            // extract the value of the feature using JSONPath
            // if the feature is "room1.temperature", convert it to "$.room1.temperature"
            const jsonPath = '$.' + feature;
            const result = JSONPath.JSONPath({ path: jsonPath, json: data });

            // if the result exists and the first element exists, use the value
            if (result && result.length > 0) {
                flat_data[feature] = result[0];
            } else {
                // if the feature is not found, set null
                flat_data[feature] = null;
                logger.warn({ feature }, 'feature not found in data');
            }
        } catch (error) {
            logger.error({ err: error, feature }, 'feature parsing error');
            flat_data[feature] = null;
        }
    }
    // also add time (e.g. ct)
    flat_data.time = time;
    
    return flat_data;
}

function batch_noti_data(dsp_ri,data) {
    const { batch_data } = require('./datasetManager');
    // batch_data[data.time] = data;
    if (!batch_data[dsp_ri]) {
        batch_data[dsp_ri] = {};
    }
    batch_data[dsp_ri][data.time] = data;
    logger.trace({ dsp_ri, batchSize: Object.keys(batch_data[dsp_ri]).length }, 'batch data updated');
}

module.exports = {
    wants_modified_attributes, 
    check_and_send_noti, 
    send_sub_del_noti,
    self_noti_handler,
    // Used by cse/missing-data-subscription.js, which is triggered by the sweep rather than by a
    // resource CRUD event and so cannot go through check_and_send_noti.
    send_a_noti,
    prefetch_ae_poa,
    // Used by cse/subscription-verification.js's verify_targets, on the subscription creation
    // path (cse/resources/sub.js).
    send_verification,
    notification_target_allowed,
};
