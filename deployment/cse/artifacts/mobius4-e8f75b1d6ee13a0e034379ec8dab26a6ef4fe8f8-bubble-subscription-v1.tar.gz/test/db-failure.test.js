"use strict";
// What the CSE says when it can no longer read its database.
//
// Reported from a containerised deployment: with the database unavailable, `/health` still
// answered 200 and every oneM2M request came back **4004 "target resource does not exist"**. Both
// describe a healthy CSE holding an empty resource tree, which is not what was happening.
//
// The 4004 came from three lookup helpers in cse/hostingCSE.js that caught their own query errors
// and returned the value they also use for "no such row" (`null`, or `0` for the type). set_ri_sid
// reads that as "the resource is not there" and reqPrim answers 4004 — a failure to *read* the
// tree was reported as a fact *about* the tree. TS-0004:6.6.3.6 (Receiver error response class)
// puts a receiver-side failure at 5000 INTERNAL_SERVER_ERROR, and prim_handling already maps a
// thrown error to that, so the fix was to stop swallowing rather than to add error handling.
//
// How the outage is simulated, and why this way
// --------------------------------------------
// Starting against a missing database does not reproduce it: db/init.js fails and the process
// exits (verified 2026-08-08 — "Error: PostgreSQL connection failed" at db/init.js:50, main()
// aborts). The reported state is a database that goes away *after* startup, so these tests start
// normally and then drop the `lookup` table, which every request path reads. Queries then fail
// for real, in-process, deterministically, with the server still up.
//
// That is a narrower failure than an unreachable host — no connection timeout, no half-open
// socket — but it exercises the branch that matters: a query that raises instead of returning
// rows. It runs against a database of its own so that breaking the schema cannot affect the
// shared test database.

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { Client } = require("pg");
const config = require("config");
const { request, CSE_BASE } = require("./helpers/onem2m");
const { startServer } = require("./helpers/server");
const { classify_create_error } = require("../cse/create-error");

const BROKEN_DB = "mobius4_test_db_failure";

let srv;
let admin;

async function withAdmin(fn) {
  const client = new Client({
    host: config.get("db.host"),
    port: config.get("db.port"),
    user: config.get("db.user"),
    password: config.get("db.pw"),
    database: "postgres",
  });
  await client.connect();
  try {
    return await fn(client);
  } finally {
    await client.end();
  }
}

before(async () => {
  await withAdmin(async (c) => {
    await c.query(`DROP DATABASE IF EXISTS ${BROKEN_DB}`);
    await c.query(`CREATE DATABASE ${BROKEN_DB}`);
  });

  // db/init.js builds the schema on first boot, so the server comes up healthy first.
  srv = await startServer({ dbName: BROKEN_DB });

  // Sanity check before breaking anything: if this is not green the rest proves nothing.
  const before_break = await fetch(`${srv.baseUrl}/health`);
  assert.equal(before_break.status, 200, "the server must be healthy before the outage");
  assert.equal((await before_break.json()).db, "ok");

  admin = new Client({
    host: config.get("db.host"),
    port: config.get("db.port"),
    user: config.get("db.user"),
    password: config.get("db.pw"),
    database: BROKEN_DB,
  });
  await admin.connect();
  await admin.query("DROP TABLE lookup CASCADE");
});

after(async () => {
  if (admin) await admin.end();
  if (srv) await srv.stop();
  await withAdmin((c) => c.query(`DROP DATABASE IF EXISTS ${BROKEN_DB}`));
});

test("/health reports 503 when the database cannot be read", async () => {
  // docker-compose.yml wires this endpoint as the container healthcheck, which is why it must not
  // answer 200 here — an orchestrator would keep an unusable container in rotation. It probes the
  // lookup table rather than `SELECT 1` so that a reachable database with a broken schema, which
  // is exactly this state, still fails the check.
  const res = await fetch(`${srv.baseUrl}/health`);

  assert.equal(res.status, 503, "503, not 500: the process is fine and the condition can clear");
  const body = await res.json();
  assert.equal(body.status, "unavailable");
  assert.equal(body.db, "unreachable");
});

test("a retrieve answers 5000, not 4004, when the database cannot be read", async () => {
  const res = await request(srv.baseUrl, { method: "GET", to: CSE_BASE });

  assert.equal(
    res.rsc,
    "5000",
    `expected INTERNAL_SERVER_ERROR, got ${res.rsc}. 4004 would tell the client the resource ` +
      `does not exist, which the CSE cannot know while it cannot read the tree`
  );
});

test("a create answers 5000 too", async () => {
  // The create path resolves its parent through the same helpers, so it failed the same way — and
  // a client retrying against a parent reported missing would have kept getting 4004.
  const res = await request(srv.baseUrl, {
    method: "POST",
    to: CSE_BASE,
    ty: 3,
    body: { "m2m:cnt": { rn: "should-not-be-created" } },
  });

  assert.equal(res.rsc, "5000");
});

test("a delete answers 5000 too", async () => {
  const res = await request(srv.baseUrl, { method: "DELETE", to: `${CSE_BASE}/anything` });

  assert.equal(res.rsc, "5000");
});

test("a contentInstance create answers 5000, not 4000, on a database failure", async () => {
  // cse/create-error.js mapped everything that was not a unique violation to 4000 BAD_REQUEST,
  // so during an outage the client was told its request was malformed. TS-0004:6.6.2 Table
  // 6.6.2-1 reserves 4xxx for "malformed by the Originator" — which decides whether a client
  // retries with backoff or stops sending.
  const res = await request(srv.baseUrl, {
    method: "POST",
    to: `${CSE_BASE}/anything`,
    ty: 4,
    body: { "m2m:cin": { con: "x" } },
  });

  assert.equal(res.rsc, "5000");
});

test("the CSEBase retrieve does not report a database failure as access denied", async () => {
  // cse/resources/cb.js caught its own error and returned a half-built resource; the access check
  // downstream then answered 4103, reporting a connection fault as a permissions problem.
  const res = await request(srv.baseUrl, { method: "GET", to: CSE_BASE });

  assert.notEqual(res.rsc, "4103", "a connection fault is not a privileges problem");
  assert.equal(res.rsc, "5000");
});

// classify_create_error unit tests -- no server needed, so these do not touch srv/admin above.
// This is the ACME scenario (M2): csz sent as MIME types overflowed the VARCHAR(10) column and
// Postgres's own wording came back in m2m:dbg. Now that cse/resources/csr.js and ae.js normalize
// csz before it reaches the database, this SQLSTATE should not occur in practice for csz -- but
// classify_create_error has to stop leaking it regardless of which column or value produced it.
test("classify_create_error maps a class-22 SQLSTATE to a fixed message, not the database's own text", () => {
  const err = {
    name: "SequelizeDatabaseError",
    original: {
      code: "22001",
      message: "value too long for type character varying(10)",
    },
  };

  const { rsc, dbg } = classify_create_error(err);

  assert.equal(rsc, 4000);
  assert.equal(dbg, "an attribute value does not fit what this CSE can store");
  assert.doesNotMatch(dbg, /value too long|character varying/, "the database's own wording must not reach the client");
});

test("classify_create_error maps a non-class-22 database error to the generic storage message", () => {
  const err = {
    name: "SequelizeDatabaseError",
    original: { code: "42601", message: "syntax error at or near \"x\"" },
  };

  const { rsc, dbg } = classify_create_error(err);

  assert.equal(rsc, 4000);
  assert.equal(dbg, "the request could not be stored");
});

test("classify_create_error leaves a non-database error's message untouched", () => {
  const err = new TypeError("Cannot read properties of undefined (reading 'foo')");

  const { rsc, dbg } = classify_create_error(err);

  assert.equal(rsc, 4000);
  assert.equal(dbg, err.message, "a bug, not a database rejection, still reports its own message");
});
