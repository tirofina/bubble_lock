"use strict";
// Two things decide access for the administrator, and both are pinned here.
//
// cse/hostingCSE.js grants the administrator every operation before any policy is read — the
// short-circuit this project has always had, removed in v4.6.0 and restored afterwards because
// resources with no acpi became unreachable and unfixable. db/init.js also creates an admin
// <accessControlPolicy> (config.cb.admin_acp) granting acop 63, which the short-circuit makes
// redundant for the administrator but which still governs anyone else named in it.
//
// Because the short-circuit answers first, the interesting assertions below are the ones about
// *other* originators: they are what would notice if restoring it had widened access for
// anybody but the administrator. Passing the suite without them would prove little — most
// resources in the other tests are created by the administrator itself.

const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { Client } = require("pg");
const config = require("config");
const { startServer, TEST_DB } = require("./helpers/server");
const { create, remove, retrieve, update, discover, urils, createRoot, uniqueRn, CSE_BASE, ADMIN } =
  require("./helpers/onem2m");

const ADMIN_ACP = `${CSE_BASE}/cb_admin_acp`;      // config.cb.admin_acp.rn
const DEFAULT_ACP = `${CSE_BASE}/cb_default_acp`;  // config.cb.default_acp.rn

// Someone who is neither the administrator nor, below, the creator of the resource under test.
const OTHER_AE = "CAE-other";
const THIRD_AE = "CAE-third";

let srv, root, parent, db;

// <accessControlPolicy> resources created by the CIN tests below. They have to live under the
// <CSEBase> (a container is not a permitted parent for ty=1), so the test root's own deletion
// does not reach them and the after() hook clears them explicitly.
const acpsToClean = [];

before(async () => {
  srv = await startServer();
  root = await createRoot(srv.baseUrl, "acl");

  // The parent has to carry the default policy for these tests to be able to set up at all.
  // createRoot makes its container as the administrator with no acpi, so the creator fallback
  // governs it and nobody else can create underneath. The administrator's short-circuit does
  // not help here — OTHER_AE and THIRD_AE are the originators that have to get in.
  const rn = uniqueRn("p");
  const res = await create(srv.baseUrl, root.sid, 3, { "m2m:cnt": { rn, acpi: [DEFAULT_ACP] } });
  assert.equal(res.rsc, "2001", `setup failed: ${res.raw.slice(0, 200)}`);
  parent = `${root.sid}/${rn}`;

  // The test database by name; config/default.json points at the development one and it is
  // test/helpers/server.js that overrides db.name for the child process.
  const { user, pw, host, port } = config.get("db");
  db = new Client({ user, password: pw, host, port, database: TEST_DB });
  await db.connect();
});

// One after() for the whole file: node:test runs them in registration order, so a second one
// declared further down would fire after srv.stop() and every request in it would fail.
after(async () => {
  for (const sid of acpsToClean) await remove(srv.baseUrl, sid);
  if (root) await root.remove();
  if (srv) await srv.stop();
  if (db) await db.end();
});

// A container created by someone other than the administrator, carrying the policies named.
async function containerOwnedByOther(acpi) {
  const rn = uniqueRn("c");
  const res = await create(srv.baseUrl, parent, 3, { "m2m:cnt": { rn, acpi } },
    { originator: OTHER_AE });
  assert.equal(res.rsc, "2001", `setup failed: ${res.raw.slice(0, 200)}`);
  return `${parent}/${rn}`;
}

test("the admin policy exists and grants the administrator all six operations", async () => {
  const res = await retrieve(srv.baseUrl, ADMIN_ACP);
  assert.equal(res.rsc, "2000", "db/init.js should have created the admin policy at startup");

  const acp = res.body["m2m:acp"];
  const rule = acp.pv.acr.find((r) => r.acor.includes(ADMIN));
  assert.ok(rule, `privileges should name the administrator: ${JSON.stringify(acp.pv)}`);
  assert.equal(rule.acop, 63, "acop 63 is all six operations");
});

test("the administrator can delete a resource it did not create, through the admin policy", async () => {
  // This is the case the removed short-circuit used to cover, and the one that proves the
  // replacement works. The creator fallback does not apply (OTHER_AE created it) and the
  // default policy cannot help either — its acop is 35, which has no delete bit (code map G-2).
  const sid = await containerOwnedByOther([DEFAULT_ACP, ADMIN_ACP]);

  const res = await remove(srv.baseUrl, sid);
  assert.equal(res.rsc, "2002", "the admin policy should grant delete");
});

test("an ordinary originator still cannot delete someone else's resource", async () => {
  // The mirror of the test above: the grant has to come from the admin policy naming the
  // administrator, not from the resource being reachable at all.
  const sid = await containerOwnedByOther([DEFAULT_ACP, ADMIN_ACP]);

  const res = await remove(srv.baseUrl, sid, { originator: THIRD_AE });
  assert.equal(res.rsc, "4103", "only the identity named in the admin policy gets these rights");
});

test("the administrator gets through a policy that grants it nothing", async () => {
  // The cheat-key, on the case where policy evaluation would refuse. The default policy grants
  // acop 35 — create, retrieve, discovery — so a resource carrying only that one has no delete
  // bit for anybody, the administrator included. Between v4.6.0 and its restoration this
  // answered 4103.
  const sid = await containerOwnedByOther([DEFAULT_ACP]);

  const res = await remove(srv.baseUrl, sid);
  assert.equal(res.rsc, "2002",
    "the short-circuit runs before any policy is read, so the missing delete bit does not decide");
});

test("the administrator gets through the creator fallback of a resource it did not create", async () => {
  // The case that motivated bringing the short-circuit back. A resource with an empty acpi is
  // governed by the creator comparison (Case D), and db/migrations/v4.6.0.sql deliberately
  // leaves such resources without a policy — so under policy evaluation alone the administrator
  // could neither read the resource nor attach a policy to it (the acpi_update path in
  // cse/reqPrim.js reads privileges off the acpi that is not there), and nothing short of a
  // direct DB write could undo that.
  const sid = await containerOwnedByOther(undefined);

  const res = await remove(srv.baseUrl, sid);
  assert.equal(res.rsc, "2002", "the creator fallback is not reached for the administrator");
});

test("the creator fallback still governs everyone else", async () => {
  // The mirror of the test above: restoring the administrator's short-circuit must not turn
  // Case D into a general amnesty. The creator gets in, a third party does not.
  const sid = await containerOwnedByOther(undefined);

  const byThird = await remove(srv.baseUrl, sid, { originator: THIRD_AE });
  assert.equal(byThird.rsc, "4103", "a third party is neither the creator nor the administrator");

  const byCreator = await remove(srv.baseUrl, sid, { originator: OTHER_AE });
  assert.equal(byCreator.rsc, "2002", "the creator is still able to delete it");
});

// ---------------------------------------------------------------------------
// A <contentInstance> is governed by its parent's policy.
//
// TS-0001:9.6.7: "The <contentInstance> resource inherits the same access control policies of
// the parent <container> resource, and does not have its own accessControlPolicyIDs
// attribute." TS-0001:9.6.1.3.2 states the general rule these fall under — a resource type
// with no accessControlPolicyIDs definition is governed some other way, the parent's policy
// being the named example.
//
// access_decision implements this as Case B: resolve the parent, then ask the same question
// about the parent instead. Until 2026-08-06 the request it built for that recursive call
// carried to_ty, ri and fr but *not* op, and access_decision_acpi switches on the operation —
// so an undefined op matched no case and every rule evaluated to false. The effect was that a
// <contentInstance> under a container carrying any acpi was unreachable by everyone, the
// administrator included, and vanished from discovery results.
//
// It stayed hidden because a container created without an acpi falls through to the creator
// comparison instead, and fr *was* carried — so the common shape (an AE reading back what it
// wrote into its own container) worked, and every test here predates the CIN cases below.
//
// The third test is the one that distinguishes "op is carried" from "op is ignored": it needs
// the retrieve bit to be honoured and the delete bit to be honoured separately.

// An <accessControlPolicy> under the <CSEBase> granting acor the operations in acop. The
// administrator is named as well, in privileges so that it can set the resources up and in
// selfPrivileges so that after() can delete the policy again. That extra rule never decides any
// assertion below: the originator under test is always OTHER_AE or THIRD_AE.
async function policyGranting(acor, acop) {
  const rn = uniqueRn("acp");
  const res = await create(srv.baseUrl, CSE_BASE, 1, { "m2m:acp": {
    rn,
    pv:  { acr: [{ acor: [acor], acop }, { acor: [ADMIN], acop: 63 }] },
    pvs: { acr: [{ acor: [ADMIN], acop: 63 }] },
  }});
  assert.equal(res.rsc, "2001", `policy setup failed: ${res.raw.slice(0, 200)}`);
  const sid = `${CSE_BASE}/${rn}`;
  acpsToClean.push(sid);
  return sid;
}

// A container under the test root carrying acpi, plus one <contentInstance> inside it, both put
// there by the administrator. Who created them does not enter into any of these decisions — the
// container has an acpi, so the creator fallback is not reached at all — and setting them up as
// the administrator is what lets a policy that names nobody else still be testable.
async function containerWithOneCin(acpi) {
  const rn = uniqueRn("c");
  const cnt = await create(srv.baseUrl, parent, 3, { "m2m:cnt": { rn, acpi: [acpi] } });
  assert.equal(cnt.rsc, "2001", `container setup failed: ${cnt.raw.slice(0, 200)}`);
  const cntSid = `${parent}/${rn}`;

  const cin = await create(srv.baseUrl, cntSid, 4, { "m2m:cin": { con: "42" } });
  assert.equal(cin.rsc, "2001", `contentInstance setup failed: ${cin.raw.slice(0, 200)}`);
  return { cntSid, cinSid: `${cntSid}/${cin.body["m2m:cin"].rn}` };
}

test("a <contentInstance> is reachable through the policy on its parent <container>", async () => {
  const acp = await policyGranting(OTHER_AE, 63);
  const { cinSid } = await containerWithOneCin(acp);

  const res = await retrieve(srv.baseUrl, cinSid, { originator: OTHER_AE });
  assert.equal(res.rsc, "2000",
    "the parent's policy grants retrieve, and the child inherits it (TS-0001:9.6.7)");
  assert.equal(res.body["m2m:cin"].con, "42");
});

test("the parent's policy decides for the child: an originator it does not name is refused", async () => {
  // The mirror of the test above. Carrying the operation into the parent's decision must not
  // turn into granting the operation.
  const acp = await policyGranting(OTHER_AE, 63);
  const { cinSid } = await containerWithOneCin(acp);

  const res = await retrieve(srv.baseUrl, cinSid, { originator: THIRD_AE });
  assert.equal(res.rsc, "4103", "THIRD_AE is named by neither the policy nor the creator");
});

test("the operation is carried into the parent's decision, not assumed", async () => {
  // acop 35 = create(1) + retrieve(2) + discovery(32), no delete bit. If the recursive call
  // dropped op, both of these would be 4103; if it substituted a permissive one, both would
  // succeed. Only carrying the real operation gives 2000 then 4103.
  const acp = await policyGranting(OTHER_AE, 35);
  const { cinSid } = await containerWithOneCin(acp);

  const read = await retrieve(srv.baseUrl, cinSid, { originator: OTHER_AE });
  assert.equal(read.rsc, "2000", "the retrieve bit is set");

  const del = await remove(srv.baseUrl, cinSid, { originator: OTHER_AE });
  assert.equal(del.rsc, "4103", "the delete bit is not set, and the child must feel that too");
});

// discovery_core memoizes each access decision by whatever actually decides it — the parent's
// ri for a parent-governed type, the resource's own ri otherwise — so that N content instances
// under one container cost one decision instead of N. These two tests are what keeps that from
// becoming "one decision for everybody".

test("discovery keeps <contentInstance> decisions apart when their parents' policies differ", async () => {
  const open = await policyGranting(OTHER_AE, 35);   // OTHER may discover
  const shut = await policyGranting(THIRD_AE, 35);   // OTHER may not
  const a = await containerWithOneCin(open);
  const b = await containerWithOneCin(shut);

  const res = await discover(srv.baseUrl, parent, {}, { originator: OTHER_AE });
  assert.equal(res.rsc, "2000");
  const found = urils(res);

  assert.ok(found.includes(a.cinSid), `the permitted CIN is missing: ${JSON.stringify(found)}`);
  assert.ok(!found.includes(b.cinSid),
    `a CIN under a policy that does not name this originator leaked in: ${JSON.stringify(found)}`);
});

test("a change to an <accessControlPolicy>'s privileges takes effect on the very next request", async () => {
  // The question the memo has to answer for: nothing in access control keys off acpi, so an
  // <acp> whose pv changes must be felt immediately. Two originators disagreeing (the test
  // below) only shows the memo is per-originator; this one changes the policy itself, which is
  // the case a cache with any lifetime beyond one request would get wrong.
  //
  // It covers both paths that read privileges: the <container> decides for itself (Case D) and
  // the <contentInstance> inherits that decision through its parent (Case B). Discovery is
  // included because that is where the memo lives.
  const rn = uniqueRn("acp");
  const made = await create(srv.baseUrl, CSE_BASE, 1, { "m2m:acp": {
    rn,
    pv:  { acr: [{ acor: [OTHER_AE], acop: 35 }, { acor: [ADMIN], acop: 63 }] },
    pvs: { acr: [{ acor: [ADMIN], acop: 63 }] },
  }});
  assert.equal(made.rsc, "2001", `policy setup failed: ${made.raw.slice(0, 200)}`);
  const acpSid = `${CSE_BASE}/${rn}`;
  acpsToClean.push(acpSid);

  const { cntSid, cinSid } = await containerWithOneCin(acpSid);

  // granted
  assert.equal((await retrieve(srv.baseUrl, cinSid, { originator: OTHER_AE })).rsc, "2000");
  assert.ok(urils(await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE })).includes(cinSid));

  // revoke: OTHER_AE drops out of privileges entirely
  const revoked = await update(srv.baseUrl, acpSid, { "m2m:acp": {
    pv: { acr: [{ acor: [ADMIN], acop: 63 }] },
  }});
  assert.equal(revoked.rsc, "2004", `pv update failed: ${revoked.raw.slice(0, 200)}`);

  assert.equal((await retrieve(srv.baseUrl, cinSid, { originator: OTHER_AE })).rsc, "4103",
    "the revocation must be felt on the next request, with no cache to wait out");
  assert.ok(!urils(await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE })).includes(cinSid),
    "a revoked originator must stop seeing the CIN in discovery immediately");

  // and back again, so this cannot pass by way of something that only ever denies
  const restored = await update(srv.baseUrl, acpSid, { "m2m:acp": {
    pv: { acr: [{ acor: [OTHER_AE], acop: 35 }, { acor: [ADMIN], acop: 63 }] },
  }});
  assert.equal(restored.rsc, "2004", `pv restore failed: ${restored.raw.slice(0, 200)}`);

  assert.equal((await retrieve(srv.baseUrl, cinSid, { originator: OTHER_AE })).rsc, "2000",
    "a re-grant must be felt just as immediately");
  assert.ok(urils(await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE })).includes(cinSid));
});

test("discovery does not list a resource that no longer has an address", async () => {
  // Sharing a decision also skips the read that produced it, and that read used to double as an
  // existence check — access_decision answers false for a resource that is gone. With decisions
  // shared, only the first resource behind each key gets read, so discovery_core checks the
  // survivors against the lookup table before returning them.
  //
  // The race that motivates it (a resource deleted between the type queries and the filter)
  // cannot be staged from outside, so the test produces the state it leaves behind instead:
  // the lookup row removed while the type row remains. That is also the state left by the
  // pre-existing DELETE_MODEL gap in the code map, and either way the answer is the same — a
  // row with no lookup entry has no address, and discovery returns addresses.
  const acp = await policyGranting(OTHER_AE, 35);
  const { cntSid, cinSid } = await containerWithOneCin(acp);

  const before = urils(await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE }));
  assert.ok(before.includes(cinSid), `setup: the CIN should start out discoverable: ${JSON.stringify(before)}`);

  const del = await db.query("DELETE FROM lookup WHERE sid = $1", [cinSid]);
  assert.equal(del.rowCount, 1, "the lookup row for the CIN should have been there to delete");

  const after = urils(await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE }));
  assert.ok(!after.includes(cinSid),
    `a resource with no lookup row must not be returned: ${JSON.stringify(after)}`);
});

test("the memo key names the originator, not only the target", async () => {
  // An access decision is a function of (originator, operation, target). The memo key carries
  // all three even though only the target varies inside one discovery loop, and this is the
  // test that says so: two originators with opposite rights over the *same* two containers,
  // asked in the same process, must each get their own answer.
  //
  // It differs from "does not outlive the request" below in what it would catch. That one fails
  // if the Map is shared across requests. This one fails if the Map is per-request but keyed on
  // the target alone and the loop is ever reused for more than one originator — the shape a
  // future change could introduce without touching anything that looks like a cache.
  const forOther = await policyGranting(OTHER_AE, 35);
  const forThird = await policyGranting(THIRD_AE, 35);
  const a = await containerWithOneCin(forOther);
  const b = await containerWithOneCin(forThird);

  const other = urils(await discover(srv.baseUrl, parent, {}, { originator: OTHER_AE }));
  const third = urils(await discover(srv.baseUrl, parent, {}, { originator: THIRD_AE }));

  // Same two containers, two originators, mirror-image answers.
  assert.ok(other.includes(a.cinSid) && !other.includes(b.cinSid),
    `OTHER_AE should see only its own: ${JSON.stringify(other)}`);
  assert.ok(third.includes(b.cinSid) && !third.includes(a.cinSid),
    `THIRD_AE should see only its own: ${JSON.stringify(third)}`);
});

test("the discovery decision memo does not outlive the request", async () => {
  // Two originators, opposite answers, back to back against the same resources. A memo promoted
  // to module scope or given a TTL would hand the second request the first one's answers — the
  // exact failure mode that makes cross-request caching of access decisions unsound.
  const open = await policyGranting(OTHER_AE, 35);
  const shut = await policyGranting(THIRD_AE, 35);
  const a = await containerWithOneCin(open);
  const b = await containerWithOneCin(shut);

  const asOther = urils(await discover(srv.baseUrl, parent, {}, { originator: OTHER_AE }));
  const asThird = urils(await discover(srv.baseUrl, parent, {}, { originator: THIRD_AE }));

  assert.ok(asOther.includes(a.cinSid) && !asOther.includes(b.cinSid), "first request");
  assert.ok(asThird.includes(b.cinSid) && !asThird.includes(a.cinSid),
    `the second originator got the first one's answers: ${JSON.stringify(asThird)}`);
});

test("discovery lists a <contentInstance> that its parent's policy makes discoverable", async () => {
  // Discovery evaluates each discovered resource with op=6, so it travels the same Case B
  // path. With op dropped, the CIN was silently filtered out of every result — a 2000 with an
  // empty list, which is far quieter than a 4103.
  const acp = await policyGranting(OTHER_AE, 35);
  const { cntSid, cinSid } = await containerWithOneCin(acp);

  const res = await discover(srv.baseUrl, cntSid, {}, { originator: OTHER_AE });
  assert.equal(res.rsc, "2000");
  assert.ok(urils(res).includes(cinSid),
    `the CIN should appear in the discovery result: ${JSON.stringify(urils(res))}`);
});

// ---------------------------------------------------------------------------
// A <timeSeriesInstance> is governed by its parent's policy — the same shape as
// <contentInstance> above, one level down. TS-0001:9.6.37: "The <timeSeriesInstance> resource
// inherits the same access control policies of the parent <timeSeries> resource, and does not
// have its own accessControlPolicyIDs attribute."
//
// cse/resources/tsi.js already has no acpi column and tsi_create_schema already has
// acpi: Joi.forbidden() — what was missing was "tsi" in NORM_RES_WITHOUT_ACPI
// (cse/hostingCSE.js), which is what routes access_decision through Case B (resolve the parent,
// decide there) instead of falling through to Case D's creator-fallback with an undefined acpi.
// Without it: an originator the parent's policy grants got 4103 on the child and the child was
// missing from discovery (under-grant), while whoever created the <tsi> kept access through the
// creator fallback even after the operator revoked it on the parent (over-grant). These four
// tests are the <contentInstance> cases above, unchanged in shape, retargeted at <tsi>.

// A <timeSeries> under the test root carrying acpi, plus one <timeSeriesInstance> inside it,
// both put there by the administrator — mirrors containerWithOneCin above.
async function seriesWithOneTsi(acpi) {
  const rn = uniqueRn("ts");
  const ts = await create(srv.baseUrl, parent, 29, { "m2m:ts": { rn, acpi: [acpi] } });
  assert.equal(ts.rsc, "2001", `<ts> setup failed: ${ts.raw.slice(0, 200)}`);
  const tsSid = `${parent}/${rn}`;

  const tsi = await create(srv.baseUrl, tsSid, 30, {
    "m2m:tsi": { dgt: "20260816T000000", con: "42" },
  });
  assert.equal(tsi.rsc, "2001", `<tsi> setup failed: ${tsi.raw.slice(0, 200)}`);
  return { tsSid, tsiSid: `${tsSid}/${tsi.body["m2m:tsi"].rn}` };
}

test("a <timeSeriesInstance> is reachable through the policy on its parent <timeSeries>", async () => {
  const acp = await policyGranting(OTHER_AE, 63);
  const { tsiSid } = await seriesWithOneTsi(acp);

  const res = await retrieve(srv.baseUrl, tsiSid, { originator: OTHER_AE });
  assert.equal(res.rsc, "2000",
    "the parent's policy grants retrieve, and the child inherits it (TS-0001:9.6.37)");
  assert.equal(res.body["m2m:tsi"].con, "42");
});

test("the parent's policy decides for a <timeSeriesInstance> child: an originator it does not name is refused", async () => {
  // The mirror of the test above. Carrying the operation into the parent's decision must not
  // turn into granting the operation.
  const acp = await policyGranting(OTHER_AE, 63);
  const { tsiSid } = await seriesWithOneTsi(acp);

  const res = await retrieve(srv.baseUrl, tsiSid, { originator: THIRD_AE });
  assert.equal(res.rsc, "4103", "THIRD_AE is named by neither the policy nor the creator");
});

test("the operation is carried into the parent's decision for a <timeSeriesInstance>, not assumed", async () => {
  // acop 35 = create(1) + retrieve(2) + discovery(32), no delete bit. If the recursive call
  // dropped op, both of these would be 4103; if it substituted a permissive one, both would
  // succeed. Only carrying the real operation gives 2000 then 4103.
  const acp = await policyGranting(OTHER_AE, 35);
  const { tsiSid } = await seriesWithOneTsi(acp);

  const read = await retrieve(srv.baseUrl, tsiSid, { originator: OTHER_AE });
  assert.equal(read.rsc, "2000", "the retrieve bit is set");

  const del = await remove(srv.baseUrl, tsiSid, { originator: OTHER_AE });
  assert.equal(del.rsc, "4103", "the delete bit is not set, and the child must feel that too");
});

test("discovery keeps <timeSeriesInstance> decisions apart when their parents' policies differ", async () => {
  const open = await policyGranting(OTHER_AE, 35);   // OTHER may discover
  const shut = await policyGranting(THIRD_AE, 35);   // OTHER may not
  const a = await seriesWithOneTsi(open);
  const b = await seriesWithOneTsi(shut);

  const res = await discover(srv.baseUrl, parent, {}, { originator: OTHER_AE });
  assert.equal(res.rsc, "2000");
  const found = urils(res);

  assert.ok(found.includes(a.tsiSid), `the permitted TSI is missing: ${JSON.stringify(found)}`);
  assert.ok(!found.includes(b.tsiSid),
    `a TSI under a policy that does not name this originator leaked in: ${JSON.stringify(found)}`);
});

// Revoking access on the parent must actually revoke it — the direction the four tests above
// cannot see.
//
// They all read a <tsi> the administrator created, as some other originator. If <tsi> fell out of
// NORM_RES_WITHOUT_ACPI those would fail too, because Case D would compare int_cr against an
// originator that is not the creator and refuse. So they pin "the parent's policy is consulted",
// but only where Case B and Case D happen to agree.
//
// The two disagree exactly when the originator IS the creator and the parent's policy says no.
// Case B refuses; Case D grants, because a <timeSeriesInstance> has no acpi column of its own and
// the empty-acpi branch falls back to int_cr == fr. That is an over-grant, and it is the shape a
// real deployment meets: an AE writes its own data, the operator later takes the AE off the
// parent's policy, and the AE keeps reading what it wrote.
test("a <timeSeriesInstance>'s creator loses access when the parent's policy stops naming it", async () => {
  const granting = await policyGranting(OTHER_AE, 63);
  const rn = uniqueRn("ts");
  const ts = await create(srv.baseUrl, parent, 29, { "m2m:ts": { rn, acpi: [granting] } });
  assert.equal(ts.rsc, "2001", `<ts> setup failed: ${ts.raw.slice(0, 200)}`);
  const tsSid = `${parent}/${rn}`;

  // OTHER_AE creates the instance, so it is the creator this time — unlike every fixture above.
  const tsi = await create(srv.baseUrl, tsSid, 30, {
    "m2m:tsi": { dgt: "20260818T000000", con: "mine" },
  }, { originator: OTHER_AE });
  assert.equal(tsi.rsc, "2001", `<tsi> setup failed: ${tsi.raw.slice(0, 200)}`);
  const tsiSid = `${tsSid}/${tsi.body["m2m:tsi"].rn}`;

  // It can read its own instance while the parent's policy still names it.
  const before = await retrieve(srv.baseUrl, tsiSid, { originator: OTHER_AE });
  assert.equal(before.rsc, "2000", "precondition: the creator can read it before revocation");

  // The operator moves the parent to a policy that does not name OTHER_AE.
  const revoked = await policyGranting(THIRD_AE, 63);
  const upd = await update(srv.baseUrl, tsSid, { "m2m:ts": { acpi: [revoked] } });
  assert.equal(upd.rsc, "2004", `revocation failed: ${upd.raw.slice(0, 200)}`);

  const after = await retrieve(srv.baseUrl, tsiSid, { originator: OTHER_AE });
  assert.equal(after.rsc, "4103",
    "the parent's policy no longer names the creator, so the child must not be readable either");

  // And the revocation is about the policy, not about that one originator: THIRD_AE, which the
  // new policy does name, can read the instance it did not create.
  const third = await retrieve(srv.baseUrl, tsiSid, { originator: THIRD_AE });
  assert.equal(third.rsc, "2000", "the new policy decides for the child, in both directions");
});
