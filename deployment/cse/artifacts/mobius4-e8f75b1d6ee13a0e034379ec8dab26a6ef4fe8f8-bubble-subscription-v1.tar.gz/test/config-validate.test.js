"use strict";
// config/validate.js — the startup guard on the admin identity.
//
// The guard exists because cse.admin grants unconditional access: cse/hostingCSE.js returns
// "granted" for any request whose From parameter matches it, before any <accessControlPolicy>
// is consulted, over plain HTTP as much as over TLS. A guessable value is therefore a full
// bypass, and versions up to v4.5.1 shipped one ("SM").
//
// The guard calls process.exit(1), so each case runs in its own child process and the exit
// code is the assertion. Running it in-process would take the test runner down with it.

const { test } = require("node:test");
const assert = require("node:assert/strict");
const path = require("node:path");
const fs = require("node:fs");
const os = require("node:os");
const { spawnSync } = require("node:child_process");

const REPO_ROOT = path.resolve(__dirname, "..");

// The guard is read against the configuration this project *ships*, so the child gets a config
// directory holding only config/default.json. Letting it read config/ directly meant an
// operator's own config/local.json -- git-ignored, present on any machine that actually runs the
// CSE -- supplied a cse.admin and the "unset" case could not arise. That failed only on
// developer machines and never in CI, which is the worst place for a test to disagree with
// itself: the red is dismissed as local noise.
const CONFIG_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "mobius4-config-guard-"));
fs.copyFileSync(path.join(REPO_ROOT, "config", "default.json"), path.join(CONFIG_DIR, "default.json"));

// Runs the guard with the given NODE_CONFIG and reports how it ended.
// Console logging is left on so that the message can be asserted, not just the exit code — a
// guard that refuses for the wrong reason is as bad as one that does not refuse.
function runGuard(overrides) {
  const merged = { logging: { level: "info", file: { enabled: false } }, ...overrides };
  const result = spawnSync(
    process.execPath,
    ["-e", "require('./config/validate').validate_config(require('./logger'))"],
    {
      cwd: REPO_ROOT,
      env: { ...process.env, NODE_ENV: "test", NODE_CONFIG_DIR: CONFIG_DIR, NODE_CONFIG: JSON.stringify(merged) },
      encoding: "utf8",
    }
  );
  return { status: result.status, output: `${result.stdout}${result.stderr}` };
}

test("refuses to start when cse.admin is the identity shipped up to v4.5.1", () => {
  const { status, output } = runGuard({ cse: { admin: "SM" } });
  assert.equal(status, 1, "a published admin identity must stop startup");
  assert.match(output, /SM/);
  assert.match(output, /shipped as the default/i, "the message must say why it is refused");
});

test("refuses to start when cse.admin is unset", () => {
  // config/default.json deliberately carries no admin identity since v4.6.0, so an operator
  // who never sets one gets stopped rather than inheriting a value from us.
  const { status, output } = runGuard({});
  assert.equal(status, 1);
  assert.match(output, /not set/i);
});

test("refuses to start when cse.admin is blank", () => {
  const { status } = runGuard({ cse: { admin: "   " } });
  assert.equal(status, 1, "whitespace is not an identity");
});

test("starts, but warns, when cse.admin is the placeholder from local.json.example", () => {
  // Not refused: it never shipped as a default, so no existing deployment runs it. Warned:
  // it is printed in this repository, so a deployment that copied the example verbatim has a
  // published admin identity.
  const { status, output } = runGuard({ cse: { admin: "Superuser" } });
  assert.equal(status, 0, "the example placeholder must not block startup");
  assert.match(output, /placeholder/i);
});

test("starts silently when cse.admin is unique to the deployment", () => {
  const { status, output } = runGuard({ cse: { admin: "an-identity-only-we-know" } });
  assert.equal(status, 0);
  assert.doesNotMatch(output, /placeholder|shipped as the default/i,
    "a properly configured deployment should get no admin warning at all");
});

// cse.admin is set in every case below so the admin guard (which runs first) never fires --
// these are only exercising validate_poa().

test("refuses to start when a cse.poa entry has no scheme", () => {
  // new URL() reads everything before the first ":" as the scheme, so "localhost:7599" parses
  // "cleanly" with scheme "localhost" rather than failing outright -- this is DEC-136's
  // motivating case (CSE_POA set without "http://").
  const { status, output } = runGuard({ cse: { admin: "an-identity-only-we-know", poa: ["localhost:7599"] } });
  assert.equal(status, 1, "a scheme-less poa must stop startup");
  assert.match(output, /localhost:7599/);
  assert.match(output, /missing scheme/i, "the message must point at the likely mistake");
});

test("refuses to start when a cse.poa entry uses a scheme this CSE does not bind", () => {
  const { status, output } = runGuard({ cse: { admin: "an-identity-only-we-know", poa: ["ftp://x"] } });
  assert.equal(status, 1, "ftp is not one of this CSE's protocol bindings");
  assert.match(output, /ftp/);
});

test("refuses to start when cse.poa is empty", () => {
  const { status, output } = runGuard({ cse: { admin: "an-identity-only-we-know", poa: [] } });
  assert.equal(status, 1, "a CSE with no advertised access point cannot be reached by anyone");
  assert.match(output, /not set or empty/i);
});

test("starts when every cse.poa entry has an allowed scheme", () => {
  const { status } = runGuard({
    cse: { admin: "an-identity-only-we-know", poa: ["http://127.0.0.1:7599", "mqtt://broker:1883"] },
  });
  assert.equal(status, 0, "http and mqtt are both bindings this CSE implements");
});

// DEC-137 (mobius4-dev-tool): cse.supported_resource_types used to control srt; it no longer
// does, since an operator must not be able to make the CSE advertise a type it does not
// implement, or hide one it does, by editing config. A deployment that still sets it (carried
// over from before v4.25.0) must keep starting -- it just stops doing anything.

test("starts, but warns, when cse.supported_resource_types is still set", () => {
  const { status, output } = runGuard({
    cse: { admin: "an-identity-only-we-know", supported_resource_types: [1, 2, 3] },
  });
  assert.equal(status, 0, "a leftover config value must not block startup");
  assert.match(output, /supported_resource_types/);
  assert.match(output, /ignored since v4\.25\.0/i);
});

test("starts silently when cse.supported_resource_types is unset", () => {
  const { status, output } = runGuard({ cse: { admin: "an-identity-only-we-know" } });
  assert.equal(status, 0);
  assert.doesNotMatch(output, /supported_resource_types/,
    "a deployment that never set the key should get no warning about it");
});
