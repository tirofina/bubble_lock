
## Useful interfaces for your applications

### Subscription/Notification

oneM2M standard supports two types of notification target, which is included in `notificationURI` (`nu`) attribute of `subscription` resources. One is resource ID of oneM2M Entity, the other is an URL.

When `nu` includes a resource ID (e.g. `Mobius/ae1`), the Hosting CSE get the address to send notification from the `pointOfAccess` (`poa`) attribute of the resource. The `poa` attribute is defined as a list of addresses. Mobius4 tries each addresse (either in HTTP or MQTT), until the successful notification delivery. Therefore the order of each address in the `poa` matters.

On the other hand, `nu` can represent a URL. As well as HTTP URL, oneM2M defines MQTT URL convention as below.
```curl
    mqtt://broker-address:port/topic
```
For the following subscription resource (partial) example, Mobius4 sends notifications to the MQTT topic `noti/temperature` to the local MQTT broker.
```json
{
    "m2m:sub": {
    	"rn": "sub1",
        "enc": {
        	"net" : [1, 3],
            "chty": [4]
        },
        "nu" : ["mqtt://localhost:1883/noti/temperature"],
        "nct": 1
    }
}
```


#### Narrowing what wakes a subscription

`eventNotificationCriteria` (`enc`) carries more than `net` and `chty`. Everything below is
optional; a subscription that sets none of it notifies on every event its `net` selects.

**`atr` — only these attributes.** With `net=1` (update of the subscribed-to resource), name the
attributes whose change should notify. An update touching anything else is silent. Without `atr`,
every attribute update notifies.

```json
{"m2m:sub": {"rn": "sub1", "nu": ["http://ipe:8000/notify"],
             "enc": {"net": [1], "atr": ["lbl"]}, "nct": 1}}
```

This is what keeps an IPE from waking itself: if it writes a response attribute back to the same
resource, an unfiltered `net=1` subscription fires on its own write.

**Value comparisons.** Ten conditions compare one attribute of the resource against a value:

| | matches when |
| :--- | :--- |
| `crb` / `cra` | `creationTime` is before / after the value |
| `ms` / `us` | `lastModifiedTime` is **after** / **before** the value |
| `exb` / `exa` | `expirationTime` is before / after the value |
| `sts` / `stb` | `stateTag` is smaller / bigger than the value |
| `sza` / `szb` | `contentSize` is **at least** / smaller than the value |

`ms` and `us` read backwards against their names — `modifiedSince` matches something modified
*after* the given time. `sza` is the only inclusive one. Timestamps are `YYYYMMDDThhmmss`, UTC, no
timezone suffix.

A resource that does not carry the compared attribute never matches: a `<container>` has no
`contentSize`, so `sza` never selects one.

**`fo` — how the comparisons combine.** `1` AND (the default), `2` OR, `3` XOR. XOR is odd parity:
three true conditions is true, not false.

```json
{"m2m:sub": {"rn": "big-and-recent", "nu": ["http://ipe:8000/notify"],
             "enc": {"net": [3], "chty": [4], "sza": 1024, "cra": "20260101T000000", "fo": 1},
             "nct": 1}}
```

That one notifies on a `<contentInstance>` created under the subscribed-to `<container>` only when
it is at least 1024 bytes **and** created after the start of 2026.

**What is refused.** `om` (`operationMonitor`) is not implemented and is rejected with 4000 rather
than accepted and ignored. `net` values 5–8 are defined by oneM2M but not implemented here and are
rejected with 5001; anything outside 1–8 is 4000. `net=8` and its `md` (`missingData`) condition
**are** implemented — see the release notes for v4.20.0.

### Emptying a test deployment

A test environment often has to start from nothing. `scripts/reset-resources.js` deletes every
oneM2M resource and leaves everything else alone:

```bash
node scripts/reset-resources.js            # says what it would delete, deletes nothing
node scripts/reset-resources.js --yes      # deletes
```

**Stop the CSE first.** The command refuses while anything is connected to the database — a running
CSE holds caches that would disagree with an emptied one, and a production deployment is always
connected, so it cannot empty one out from under itself.

Then start the CSE. It recreates the `<CSEBase>` and the default and administrator access control
policies from configuration, so there is no third step.

| | |
| :--- | :--- |
| **Deleted** | every `<AE>`, `<container>`, `<contentInstance>`, `<timeSeries>`, `<subscription>`, `<group>`, `<accessControlPolicy>`, `<remoteCSE>` and the AI/ML resources — all of it, with no way back. There is no soft delete in this CSE |
| **Kept** | `config/`, the database, its schema and indexes, the PostGIS extension, `config/specializations.json`, and the administrator identity file |

The target is whatever `db.name` resolves to in the configuration in effect. Print it before
trusting it — the dry run does, along with the row count per table. Add `--expect <database>` to
make the command refuse if the configuration resolves to anything else:

```bash
node scripts/reset-resources.js --yes --expect mobius4_test
```

Dropping the `public` schema in a database client and recreating it has the same effect, but it
also drops the PostGIS extension. That happens to work because the CSE reinstalls it on the next
start — do not reach for `TRUNCATE` on every table in the schema as a shortcut, because
`spatial_ref_sys` belongs to PostGIS and emptying it does *not* repair itself: `CREATE EXTENSION IF
NOT EXISTS` does nothing once the extension is registered.

Under Docker, stop the CSE first — the command refuses while it is connected — and then run it in
a throwaway container:

```bash
docker compose stop mobius4
docker compose run --rm --no-deps mobius4 scripts/reset-resources.js --yes
docker compose start mobius4
```

No `--entrypoint` override is needed. The entrypoint runs the arguments it is given, with the
deployment's own configuration assembled from the environment — which is the part that matters,
because `--entrypoint node` would skip that assembly and send the script to `localhost` instead of
the deployment's database.

### Group fan-out

Group feature with `group` and `fanOutPoint` resource type in the oneM2M specification provides request fan-out which is basically the batch resource access (CRUD) feature. One use case is that retrieving  `contentInstance` resources of multiple `container` resources that represent different sensor readings.

Mobius4 supports non-blocking access to group members during the group fan-out. Also, adding postfix to fan-out target, which is the standard feature, is implemented.

Here's the example group resource creation request HTTP body:
```json
{
    "m2m:grp": {
    	"rn": "grp1",
        "mnm" : 10,
        "mid" : [
            "Mobius/cnt1/la",
            "Mobius/cnt2/la"
        ]
    }
}
```
In this example, `memberIDs` (`mid`) includes two `latest` (`la`) virtual resources of the two `container` resources. When an AE requests to retrieve the `fanOutPoint` (`fopt`) virtual resource (e.g. `Mobius/grp1/fopt`), the two latest `contentInstance` resources are returned.

There is another way of doing the same. The `group` resource creation request below includes the containers as the group members. After the creation, to get the latest `contentInstances` from this group is to send the retrieve request to `Mobius/grp2/fopt/la` for instance. Note that there is `/la` path in the end of the request target, which is appended in the end of each group member during the fan-out. (e.g. `Mobius/cnt1/la`).

```json
{
    "m2m:grp": {
    	"rn": "grp2",
        "mnm" : 10,
        "mid" : [
            "Mobius/cnt1",
            "Mobius/cnt2"
        ]
    }
}
```

#### Members hosted on another CSE

A group member does not have to live on the CSE hosting the `<group>`. A member ID in
SP-relative form — `/{CSE-ID}/{path}` — names a resource on another CSE, and as long as that CSE
is registered (there is a `<remoteCSE>` for it with a usable `pointOfAccess`), the fan-out
reaches it and its response comes back in the aggregation alongside the local ones.

```json
{
    "m2m:grp": {
        "rn": "grp3",
        "mnm": 10,
        "mt": 3,
        "mid": [
            "Mobius/cnt1",
            "/mobius4b/Mobius/cnt9"
        ]
    }
}
```

When `memberType` (`mt`) is set, the CSE reads each member's `resourceType` to check it — for a
remote member, by retrieving it from its Hosting CSE. Three things can happen, and they are not
the same:

| what happened | the answer |
|---|---|
| the type was read | the member is judged against `mt`, and `consistencyStrategy` decides the rest |
| the member's CSE refused for lack of privilege | the whole request is rejected, **5105 RECEIVER_HAS_NO_PRIVILEGE** |
| the member's CSE could not be reached | the member **stays** in the group and `memberTypeValidated` (`mtv`) comes back **false** |

So `"mtv": false` in a response is not a failure. It says the CSE has not yet been able to check
some members, and the group is usable in the meantime.

A fan-out to a group that has no members at all is rejected with **4109 NO_MEMBERS** rather than
answering 2000 with an empty aggregation.

### _Result Content_ parameter

_Result Content_ (`rcn`) request parameter specifies what content will be included in a response. Mobius4 supports the following `rcn` values for child resources.

| `rcn` | Returns | Target's own attributes |
|-------|---------|-------------------------|
| 4 | child resources inline | included |
| 8 | child resources inline | omitted |
| 5 | child resource *references* (`ch`) | included |
| 6 | child resource *references* (`m2m:rrl`) | omitted |

These four values work on **DELETE** as well as RETRIEVE (`TS-0001:8.1.2` Table 8.1.2-1): the
response carries the resources as they were immediately before removal, which is the only chance to
see them. The default for DELETE is still "nothing".

The two families are mutually exclusive by schema: `CDT-<resourceType>.xsd` puts the reference
form and the inline form in the same `xs:choice`, so a response carries one or the other.

For better performance, it is suggested to limit the level and resource type (e.g. `lvl=1&ty=4` in HTTP query string). 

**Descendants are nested under their own parent** when `lvl` reaches beyond the direct children
(`TS-0004:8.4.3` EXAMPLE 3). Retrieving `Mobius/sensors?rcn=4&lvl=2` over a tree of
`sensors > {humid01 > h1, temp01 > (t1, t2), sub-a}` gives:

```jsonc
{"m2m:cnt": {"rn": "sensors", /* ... */
   "m2m:cnt": [{"rn": "humid01", /* ... */ "m2m:cin": [{"rn": "h1"}]},
               {"rn": "temp01",  /* ... */ "m2m:cin": [{"rn": "t1"}, {"rn": "t2"}]}],
   "m2m:sub": [{"rn": "sub-a"}]}}
```

**Pagination.** `lim` bounds the number of resources returned and cuts only on subtree
boundaries — a direct child whose descendants do not all fit is left out whole, as
`TS-0001:8.1.2` requires. When that happens the response carries `X-M2M-CTS: 1` (partial) and
`X-M2M-CTO`, which names the next unprocessed **direct child**; send that value back as `ofst`
to continue. If a single direct child's subtree is larger than `lim` the response has no children
at all and only a larger `lim` helps — the server logs a warning in that case.

`ofst` is **1-based**: `ofst=1` starts at the first direct child, so it returns the same thing as
omitting `ofst` altogether (`TS-0004:7.3.3.17.15`, "An offset of 1 shall indicate the first direct
child resource"). `X-M2M-CTO` is emitted in the same base, so echoing it back always lands exactly
where the previous response stopped.

Check the response format with the following examples.

`rcn=4` HTTP request and response example targeting a container resource.

 ```curl
    GET Mobius/cnt1?rcn=4&lvl=1&ty=4 HTTP/1.1
 ```

HTTP response body looks like:
```json
{
    "m2m:cnt": {
        "ty": 3,
        "et": "20260830T022649",
        "ct": "20250830T022649",
        "lt": "20250830T022649",
        "ri": "lhteublh9s",
        "rn": "cnt1",
        "pi": "nqtzgi6ksx",
        "cni": 9,
        "cbs": 136,
        "st": 12,
        "mni": 10000,
        "mbs": 10000000,
        "mia": 2592000,
        "m2m:cin": [
            {
                "ty": 4,
                "et": "20260830T022833",
                "ct": "20250830T022833",
                "lt": "20250830T022833",
                "ri": "9ek106jsc6",
                "rn": "cin-1bcRDKUcfY",
                "pi": "lhteublh9s",
                "st": 4,
                "cs": 16,
                "con": {
                    "humi": 40.4716042688265,
                    "temp": 22.70711665195612
                }
            },
            {
                "ty": 4,
                "et": "20260830T022903",
                "ct": "20250830T022903",
                "lt": "20250830T022903",
                "ri": "8hdwfdwewc",
                "rn": "cin-1v8Hy4uABc",
                "pi": "lhteublh9s",
                "st": 10,
                "cs": 16,
                "con": {
                    "humi": 44.41566784040748,
                    "temp": 20.185816629431198
                }
            }
        ]
    }
}
```

`rcn=8` HTTP request and response example targeting a container resource.

 ```curl
    GET Mobius/cnt1?rcn=8&lvl=1&ty=4 HTTP/1.1
 ```

HTTP response body looks like:

```json
{
    "m2m:cnt": {
        "m2m:cin": [
            {
                "ty": 4,
                "et": "20260830T022833",
                "ct": "20250830T022833",
                "lt": "20250830T022833",
                "ri": "9ek106jsc6",
                "rn": "cin-1bcRDKUcfY",
                "pi": "lhteublh9s",
                "st": 4,
                "cs": 16,
                "con": {
                    "humi": 40.4716042688265,
                    "temp": 22.70711665195612
                }
            },
            {
                "ty": 4,
                "et": "20260830T022903",
                "ct": "20250830T022903",
                "lt": "20250830T022903",
                "ri": "8hdwfdwewc",
                "rn": "cin-1v8Hy4uABc",
                "pi": "lhteublh9s",
                "st": 10,
                "cs": 16,
                "con": {
                    "humi": 44.41566784040748,
                    "temp": 20.185816629431198
                }
            }
        ]
    }
}
```


### flexContainer specializations

A `<container>` keeps its data in `<contentInstance>` children. A `<flexContainer>` instead
carries the data **directly on itself**, as attributes whose names and types are chosen by
whoever defines the specialization — a smart parking block, a light bulb, a thermostat. oneM2M
calls those `[customAttribute]` members, and the `containerDefinition` (`cnd`) attribute is what
says which set applies.

#### 1. Register the specialization

`cnd` is a URI identifying the document that defines the specialization. TS-0004:7.4.37.2.1
requires the CSE to validate every request against that definition, and to answer
`SPECIALIZATION_SCHEMA_NOT_FOUND` when it cannot find it. Each specialization you intend to
accept is declared once in **`config/specializations.json`**, whose whole content is the
registry, keyed by `cnd` URI:

```json
{
    "http://developers.iotocean.org/schema/parkingBlock.xsd": {
        "typeName": "parkingBlock",
        "namespacePrefix": "sc",
        "attributes": {
            "type":                { "type": "string"  },
            "name":                { "type": "string"  },
            "category":            { "type": "array"   },
            "availableSpotNumber": { "type": "integer" },
            "totalSpotNumber":     { "type": "integer" },
            "refParkingSpot":      { "type": "array"   }
        }
    }
}
```

That file is **generated, not hand-edited**. `node scripts/build-specializations.js` builds it
from `config/specializations.manifest.json`, which pairs each `cnd` with the XSD its attributes
are read from, and the build **overwrites** the registry — a hand edit survives only until the
next build. So you add a specialization by adding a manifest entry and running the build; the
manifest format, the rules an XSD has to follow and the Docker form of the command are all in
[docs/examples/specializations/](examples/specializations/README.md).

The registry is separate from `config/default.json` and is read directly rather than through the
`config` package, so `local.json` layering does not apply. The full key reference is in
[Configuration](configuration.md#flexcontainer-specializations). **The CSE reads this at
startup, so restart after a build.**

> **`cnd` is an identifier, not something the CSE fetches.** It is typed `xs:anyURI`, and
> nothing in oneM2M requires it to be dereferenceable. The official conformance suite uses
> values like `urn:m2m:CDT-gis-v2_21_0.xsd` and `org.onem2m.home.device.deviceLight`, neither of
> which resolves to anything over the network. Mobius4 matches the value as an opaque string
> against the table above and never issues a request for it — resolving an arbitrary URL on the
> CREATE path would make resource creation depend on an external host being reachable.
>
> An `http(s)` URL that really does serve the XSD is still a good choice, because it gives
> people reading your payloads somewhere to look. Just treat publishing the file as
> documentation for humans and other tools, not as something this CSE consumes.

Two things in that entry decide what a valid request looks like:

- `namespacePrefix` + `typeName` form the **envelope key**: `sc:parkingBlock`. This is not
  `m2m:` — TS-0004:7.4.37.1 allows a specialization to use its own namespace, and Mobius4 stores
  the key you send and replays it in every response and notification.
- `attributes` is the set of custom attribute names you may use. Names are matched exactly as
  they appear on the wire; the CSE performs no long-name/short-name translation, because the
  oneM2M short-name tables (TS-0004 clauses 8.2.2–8.2.5) only cover oneM2M-defined names and a
  third-party specialization has none.

#### 2. Create

`ty=28` in the `Content-Type` selects the operation, exactly as with other resource types.
`cnd` is mandatory here and cannot be changed afterwards.

```curl
curl -X POST http://127.0.0.1:7599/Mobius \
  -H 'X-M2M-Origin: CAE1' -H 'X-M2M-RI: 12345' -H 'X-M2M-RVI: 3' \
  -H 'Content-Type: application/json; ty=28' \
  -d '{
        "sc:parkingBlock": {
            "rn": "flx1",
            "cnd": "http://developers.iotocean.org/schema/parkingBlock.xsd",
            "type": "ParkingBlock",
            "name": "KETI_Block_A",
            "category": [],
            "availableSpotNumber": 3,
            "totalSpotNumber": 49,
            "refParkingSpot": ["wdc_base/sync_parking/parkingLot_KETI/parkingSpot_001"]
        }
      }'
```

A `<flexContainer>` may be created under `<CSEBase>`, `<AE>`, `<remoteCSE>`, `<container>`, or
another `<flexContainer>`. It can itself hold `<container>`, `<subscription>` and nested
`<flexContainer>` children.

The response echoes the resource with the attributes the CSE generated — note `cs`
(`contentSize`, the size of the custom attributes) and `st` (`stateTag`), both of which are
read-only and must not be sent in a request:

```json
{
    "sc:parkingBlock": {
        "ty": 28,
        "et": "20270802T063056",
        "ct": "20260802T063056",
        "lt": "20260802T063056",
        "ri": "runwgwrlz5",
        "rn": "flx1",
        "pi": "awjnpfnrnh",
        "st": 0,
        "cnd": "http://developers.iotocean.org/schema/parkingBlock.xsd",
        "cs": 170,
        "name": "KETI_Block_A",
        "type": "ParkingBlock",
        "category": [],
        "refParkingSpot": ["wdc_base/sync_parking/parkingLot_KETI/parkingSpot_001"],
        "totalSpotNumber": 49,
        "availableSpotNumber": 3
    }
}
```

Custom attributes come back in a different order than they were sent — they are stored as a
single JSONB value, which does not preserve key order. Read them by name, not by position.

#### 3. Update

Send only what changes. Attributes you omit are left alone; sending `null` removes an optional
one. A **mandatory** custom attribute cannot be removed that way — the specialization's XSD decides
which are mandatory, and `null` on one of those is rejected with 4000.

```curl
curl -X PUT http://127.0.0.1:7599/Mobius/flx1 \
  -H 'X-M2M-Origin: SM' -H 'X-M2M-RI: 12345' -H 'X-M2M-RVI: 3' \
  -H 'Content-Type: application/json' \
  -d '{ "sc:parkingBlock": { "availableSpotNumber": 7 } }'
```

**`stateTag` behaves differently here than on a `<container>`.** TS-0001:9.6.35 scopes the
increment to custom attribute changes, so updating `availableSpotNumber` bumps `st` and
recomputes `cs`, while updating only `lbl` or `acpi` leaves both untouched. If you are polling
`st` to detect new data, that is the distinction you are relying on.

`cnd` is write-once — including it in an UPDATE is rejected, even with the same value.

#### 4. Retrieve, delete, and discover

RETRIEVE and DELETE need no special handling:

```curl
curl http://127.0.0.1:7599/Mobius/flx1 -H 'X-M2M-Origin: SM' -H 'X-M2M-RI: 12345' -H 'X-M2M-RVI: 3'
curl -X DELETE http://127.0.0.1:7599/Mobius/flx1 -H 'X-M2M-Origin: SM' -H 'X-M2M-RI: 12345' -H 'X-M2M-RVI: 3'
```

Discovery accepts `cnd` as a filter criterion, which is the practical way to find every
resource of one specialization across the tree:

```curl
curl 'http://127.0.0.1:7599/Mobius?fu=1&cnd=http://developers.iotocean.org/schema/parkingBlock.xsd' \
  -H 'X-M2M-Origin: SM' -H 'X-M2M-RI: 12345' -H 'X-M2M-RVI: 3'
```

```json
{ "m2m:uril": ["Mobius/flx1", "Mobius/lot_KETI/blockA", "Mobius/lot_KETI/blockB"] }
```

Because `cnd` only exists on `<flexContainer>`, this filter implicitly restricts the search to
`ty=28`; other resource types are never returned. Pass several values separated by spaces to
match any of them. `?fu=1&ty=28` returns every flexContainer regardless of specialization.

#### 5. What gets rejected, and why

| Situation | RSC | HTTP |
| :--- | :--- | :--- |
| `cnd` missing on CREATE | 4000 | 400 |
| `cnd` not in `specializations` | 4125 `SPECIALIZATION_SCHEMA_NOT_FOUND` | 501 |
| Envelope key is not `prefix:typeName` from the entry | 4000 | 400 |
| Custom attribute not declared in `attributes` | 4000 | 400 |
| Declared custom attribute with the wrong type | 4000 | 400 |
| Mandatory custom attribute missing on CREATE | 4000 | 400 |
| Mandatory custom attribute set to `null` on UPDATE | 4000 | 400 |
| `cnd` included in an UPDATE | 4000 | 400 |
| Parent is not one of the allowed types | 4108 | 403 |
| `mni`, `mbs` or `mia` with a non-zero value | 5001 `NOT_IMPLEMENTED` | 501 |

A 4125 almost always means a typo in `cnd`, or an entry that was added to configuration without
restarting the CSE.

The last row is a deliberate limitation rather than a validation rule. Those three attributes
drive the creation of `<flexContainerInstance>` children — the timestamped history of a
flexContainer — and TS-0004:7.4.37.2.1 makes a non-zero value the trigger for creating them.
Mobius4 does not implement `<flexContainerInstance>` yet, so it rejects the attributes instead
of storing them, which would report success for a retention policy that never runs. For the
same reason the `<latest>` and `<oldest>` virtual resources are not available under a
`<flexContainer>`; use `<container>` and `<contentInstance>` if you need history today.


## `missingDataList` is empty when I expect entries

A `<timeSeries>` with `missingDataDetect: true` skips a data point, you RETRIEVE the resource, and
there is no `missingDataList` attribute at all. Three things produce that, in the order worth
checking.

**1. Detection has not happened yet.** `TS-0001:10.2.4.29` sets the moment a point is declared
missing:

```
missing data detection time = expected dataGenerationTime + missingDataDetectTimer
```

`missingDataDetectTimer` (`mdt`) is optional and the standard gives it no default, so mobius4
supplies one: `default.timeSeries.mdt_default`, **60000 ms** as shipped. A `<timeSeries>` with
`periodicInterval: 10000` (ten seconds) therefore reports nothing for a full minute after a gap —
the gap is real and will be listed, just not yet.

Either set `mdt` on the resource, which is the direct control:

```json
{"m2m:ts": {"rn": "ts1", "pei": 10000, "peid": 0, "mdt": 2000, "mdd": true}}
```

or lower the deployment default in `config/local.json`:

```json
{"default": {"timeSeries": {"mdt_default": 2000}}}
```

`mdt` must be greater than `periodicIntervalDelta` when that is present (`TS-0001:9.6.36`).
mobius4 enforces this on a value you supply, and raises the deployment default to
`periodicIntervalDelta + 1` when it would otherwise be too small — so the constraint holds either
way. `pei`, `peid` and `mdt` are all **in milliseconds**. `TS-0001:9.6.36` types them as
`xs:positiveInteger` and states no unit; this is what a conformance tester's own arithmetic
requires, and mobius4 read them as seconds until v4.23.0. A period below one second cannot be
represented in `missingDataList`, whose entries are `m2m:timestamp` values with one-second
resolution.

**2. Nothing is being detected at all.** Detection runs only when `missingDataDetect` is `true`
*and* `periodicInterval` is set (`TS-0001:10.2.4.21`). `mdd` defaults to `false`, so a
`<timeSeries>` created without it detects nothing. RETRIEVE the resource and read `mdd` back — it
is always present in the representation, unlike `mdlt`.

**3. The list is empty, and an empty list is not sent.** `missingDataList` is `0..1 (L)`, so
mobius4 omits it rather than sending `[]`. `missingDataCurrentNr` (`mdc`) *is* always present:
`mdc: 0` with no `mdlt` means "nothing detected", not "attribute unsupported". Check `mdc` first.

### A gap the CSE cannot see: `dataGenerationTime` in the future

Expected data points are `dataGenerationTime of the first instance + N × periodicInterval`. If the
first `<timeSeriesInstance>` carries a `dgt` ahead of the CSE's clock, every expected point is in
the future too and nothing is ever overdue.

`m2m:timestamp` carries no timezone — the format is `YYYYMMDDThhmmss` and nothing more — so both
ends must already agree on which zone it means. Compare the `dgt` you send against the `ct` the CSE
puts on the same resource: `ct` is the CSE's own clock, and if `dgt` runs ahead of it, the sender is
stamping local time where the receiver reads something else.

## Turning on subscription verification

By default, creating a `<subscription>` does not consult the notification target. With
`cse.subscription_verification` set, the CSE first sends that target a verification NOTIFY and
refuses the creation unless it answers.

```json
{"cse": {"subscription_verification": true}}
```

in `config/local.json`, then restart. It is off in `config/default.json` because
`TS-0004:7.4.8.2.1` Recv-6.4 says the Hosting CSE **may** do this, not shall — it is a deployment
choice, not a conformance requirement. Turn it on to run the oneM2M conformance tests that depend
on it; leave it off if notification targets in your deployment are not reliably reachable, because
an unreachable one now fails subscription creation instead of merely missing notifications.

### What it applies to

Only `notificationURI` entries that are **oneM2M resource IDs and are not the Originator**. The
clause scopes it that way, and `TS-0001:9.6.8` gives the same split a reason: the CSE "shall expect
to receive a response for the notification request only if the Notification Target ... is in the
oneM2M compliant Resource-ID format". A plain URL target cannot answer, so it cannot be verified.

```
nu: ["Mobius/ae1"]                    verified
nu: ["/Mobius4/Mobius/ae1"]           verified (same AE, SP-relative spelling)
nu: ["http://host/notify"]            not verified — a URL, unchanged behaviour
nu: [<the Originator itself>]         not verified — the clause excludes it
```

A subscription with no resource-ID target behaves exactly as it did before, whether the setting is
on or off.

### What the creation answers when verification fails

`5204` SUBSCRIPTION_VERIFICATION_INITIATION_FAILED, for both failures `TS-0004:7.4.8.2.1` Recv-6.4
distinguishes: the request could not be sent at all, or it was sent and the target answered
something other than 2000. The `<subscription>` is not created — verification runs before the
insert, so there is no partially-created resource to clean up.

The verification NOTIFY is dialled at the target `<AE>`'s `pointOfAccess`, and only `http` entries
are tried. An `<AE>` reachable only over MQTT therefore cannot be verified, and a subscription
naming it is refused 5204. It carries `verificationRequest`, `creator`, and
`subscriptionReference` naming the `<subscription>` about to be created — that last one is
mandatory on every notification (`TS-0004` table 6.3.5.13-1) even though the verification procedure
clause does not mention it. It carries no `notificationEvent`, and therefore no
`notificationEventType`: the same table says `net` "shall only be present if the notificationEvent
parent element is present, otherwise it shall not", and a verification request reports no event.
The timeout is `cse.notification_timeout_seconds`.

### Being a verification target

The other direction needs no configuration. A NOTIFY carrying `verificationRequest` is answered by
checking that both the `creator` named in it and the Originator sending it hold NOTIFY privilege on
the addressed resource, per `TS-0004:7.5.1.2.3`:

| Outcome | Response |
|---|---|
| both hold NOTIFY | `2000` |
| the creator does not | `4101` SUBSCRIPTION_CREATOR_HAS_NO_PRIVILEGE |
| the Originator does not | `5205` SUBSCRIPTION_HOST_HAS_NO_PRIVILEGE |
| no `creator` in the request | `4000` |

Grant it the way any other privilege is granted — an `<accessControlPolicy>` whose `acop` includes
the NOTIFY bit (16), named in the target resource's `acpi`.

## Changes from previous version of Mobius

### Subscription/Notification

For the MQTT notifications, the previous Mobius interpreted the MQTT URL in the `nu` attribute into the MQTT topic as follows. Note that `Mobius2` is the CSE-ID of the previous Mobius.

| notificationURI (nu) | notification topic | 
| :--- | :--- |
| mqtt://localhost:1883/SAE1?ct=json | /oneM2M/req/Mobius2/SAE1/json |


As explained above for [subscription/notification feature](#subscriptionnotification), following the latest version of the oneM2M spec, Mobius4 works as below.

| notificationURI (nu) | notification topic | 
| :--- | :--- |
| mqtt://localhost:1883/noti?ct=json | noti/json |
| mqtt://localhost:1883/noti/temp?ct=json | noti/temp/json |